# ppt-agent-native

ppt-agent v4.1 工作流的**纯原生 PPTX** 版本：工作流（P0→P5 状态机、subagent 合同、Gate、密度合同、人工审计、重试回退）与原版完全一致，渲染底座整体替换——

```
HTML → PNG/SVG → 图片型 pptx        （原版，已弃用）
slide-N.spec.json → PptxGenJS → 原生可编辑 presentation.pptx   （本版）
```

- **运行环境**：Windows + VS Code（GitHub Copilot）+ 桌面版 PowerPoint（交互式会话）
- **技术栈**：Node.js + PptxGenJS（生成）· PowerShell + PowerPoint COM（导出/QA）· Python（harness/validator）
- **不需要 LibreOffice**

## 安装（Windows）

```powershell
# 本目录下
npm install            # 安装 pptxgenjs（package.json 已声明）
python --version       # 3.10+；validator 全部零第三方依赖
# 桌面版 PowerPoint 必须已安装并可交互启动
```

## 核心链路

| 阶段 | 产物 | 工具 | Gate |
|---|---|---|---|
| P4-4A Planning | planningN.json | subagent | planning_validator.py |
| P4-4B Spec | specs/slide-N.spec.json | subagent | **spec_validator.py spec** |
| P4-4C Build & Review | build/slide-N.pptx + png/page-N/slide-01.png | slide_builder.js + ppt_export.ps1 | **ppt_export.ps1 -Mode qa**（文字溢出/出画布）+ 图审 |
| P5 交付 | presentation.pptx + .pdf + preview.html | deck_assembler.js + ppt_export.ps1 -Mode all | COM 打开洁净度 + contract_validator delivery-manifest |

spec 是唯一修改面；.pptx/.png 是一次性构建产物。全部命令见 `references/cli-cheatsheet.md`。

## 目录

- `SKILL.md` — 主控制台合同（native 版）
- `lib/render_core.js` — 唯一渲染器（所有 pptxgenjs 坑集中于此）
- `scripts/` — slide_builder.js · deck_assembler.js · spec_validator.py · ppt_export.ps1 + 原版 harness/validator（已适配）
- `references/` — spec-guide、layouts（英寸网格）、blocks/charts（原生配方）、styles（token 预置）、prompts/playbooks（native 版）
- `schema/defaults.json` — builder 与 validator 共享的默认值真源
- `test/specs/` — 4 页示例 deck（cover/图表页/表格页/end）

## 已在 macOS 上验证（开发机）

- `check_skill.py`：0 errors
- `smoke_skill.py`：全链路通过（含 spec Gate 正/负用例、全部 Step 0–4 prompt 生成）
- 4 页示例 deck：spec Gate 全过 → 构建 → `presentation.pptx` 通过 OOXML 结构/关系/图表全套校验（Anthropic validate.py）
- 负用例：出画布 frame、坏 token、超装饰预算、image_policy 违例、小字号均被 Gate 拦截

## 需在 Windows 上验证（COM 层，macOS 无法执行）

```powershell
# 1. 洁净度：应输出 CHECK OK 且无修复弹窗
powershell -ExecutionPolicy Bypass -File scripts\ppt_export.ps1 -Mode check -InputFile test\out\presentation.pptx

# 2. PNG 导出：应生成 slide-01..04.png（3840x2160）
powershell -ExecutionPolicy Bypass -File scripts\ppt_export.ps1 -Mode png -InputFile test\out\presentation.pptx -OutDir test\out\png

# 3. 结构 QA：应 0 fatal（把 test/specs/slide-3.spec.json 的某个 card body 塞爆可验证溢出检测）
powershell -ExecutionPolicy Bypass -File scripts\ppt_export.ps1 -Mode qa -InputFile test\out\presentation.pptx -Out test\out\qa.json

# 4. PDF：应生成 presentation.pdf
powershell -ExecutionPolicy Bypass -File scripts\ppt_export.ps1 -Mode pdf -InputFile test\out\presentation.pptx -Out test\out\presentation.pdf

# 5. 并发队列：同时起 3 个 -Mode png 进程，应串行完成且事后无残留 POWERPNT.EXE
# 6. 在 PowerPoint 中打开 presentation.pptx：文字/表格/图表应全部可编辑，备注页有内容
```
