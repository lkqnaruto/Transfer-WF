# CLI 速查表（native / Windows 版）

> 按步骤组织的完整命令手册。执行时用实际路径替换 `SKILL_DIR` / `OUTPUT_DIR` 等变量。
> 主 agent 进入 Step 0 前必须读取此文件建立接口认知。禁止对任何脚本跑 `--help`。
> 运行环境：Windows（VS Code 终端）。Python 命令统一用 `python`（不是 `python3`）；
> Node 脚本用 `node`；COM 脚本用 `powershell -ExecutionPolicy Bypass -File`。
> 前置依赖：Node.js LTS + 本 skill 目录内 `npm install` 过 pptxgenjs；桌面版 PowerPoint（交互式会话）。

---

## Step 0 采访

Prompt 生成（按能力二选一）：

**A. Structured UI 模式**

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-interview-structured-ui.md \
  --var TOPIC="用户主题" \
  --var USER_CONTEXT="用户已提供的背景信息" \
  --inject-file INTERVIEW_MODE_MODULE=SKILL_DIR/references/prompts/module-structured-interview-ui.md \
  --inject-file INTERVIEW_CORE=SKILL_DIR/references/prompts/tpl-interview.md \
  --output OUTPUT_DIR/runtime/prompt-interview.md
```

**B. Text Fallback 模式**

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-interview-text-fallback.md \
  --var TOPIC="用户主题" \
  --var USER_CONTEXT="用户已提供的背景信息" \
  --inject-file INTERVIEW_MODE_MODULE=SKILL_DIR/references/prompts/module-text-interview-fallback.md \
  --inject-file INTERVIEW_CORE=SKILL_DIR/references/prompts/tpl-interview.md \
  --output OUTPUT_DIR/runtime/prompt-interview.md
```

执行规则：

1. 先根据 `## 采访 UI 能力` 结论判断当前模式：`structured-ui` 或 `text-fallback`
2. Structured UI 模式使用 A 命令；Text Fallback 模式使用 B 命令
3. 两种模式都必须先生成 `OUTPUT_DIR/runtime/prompt-interview.md`
4. Text Fallback 模式也必须输出分组明确的 Markdown 采访单，不得退化成单行填空或散乱追问
5. 仅当 `prompt_harness.py` 在 Step 0 发生真实接口故障，并已判定 `BLOCKED_SCRIPT_INTERFACE` 时，才允许完全绕过 `prompt-interview.md` 直接发问；覆盖维度不得低于 `tpl-interview.md`

Gate 校验：

```bash
python SKILL_DIR/scripts/contract_validator.py interview OUTPUT_DIR/interview-qa.txt
python SKILL_DIR/scripts/contract_validator.py requirements-interview OUTPUT_DIR/requirements-interview.txt
```

---

## Step 1 输入识别与资料锁定

主 agent 直接执行（无 subagent）。本 skill 只支持本地资料管线（不做联网检索）：

1. 识别并归类用户输入（大段文本 / 单文件 / 多文件 / 现成 pptx）
2. 若用户尚未提供任何资料：[WAIT_USER] 请用户上传或粘贴资料后再继续；资料明显不足以支撑目标页数时，报出缺口由用户裁决
3. 回填 `requirements-interview.txt`：资料清单 + `material_strategy: local_only`

```bash
# 直接在文件中找到 "- 资料使用策略：" 一行，写入 local_only 与资料清单
```

Gate 校验：

```bash
python SKILL_DIR/scripts/contract_validator.py requirements-interview OUTPUT_DIR/requirements-interview.txt
```

---

## Step 2B 本地资料压缩（渐进式上下文注入）

> **Subagent 强制**：本步产物必须由 SourceSynth subagent 生成，主 agent 禁止内联生产。
> subagent 内部自主按阶段渐进：资料读取+提炼 -> 质量自审+边界校验。

**1. 生成阶段 prompt 文件（主 agent 执行）：**

```bash
# Phase 1: 资料读取与结构化提炼
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-source-synth-phase1.md \
  --var REQUIREMENTS_PATH=OUTPUT_DIR/requirements-interview.txt \
  --var SOURCE_INPUT=用户资料路径（目录或文件） \
  --var BRIEF_OUTPUT=OUTPUT_DIR/source-brief.txt \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/source-phase1-playbook.md \
  --output OUTPUT_DIR/runtime/prompt-source-phase1.md

# Phase 2: 质量自审与边界校验
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-source-synth-phase2.md \
  --var BRIEF_OUTPUT=OUTPUT_DIR/source-brief.txt \
  --var REQUIREMENTS_PATH=OUTPUT_DIR/requirements-interview.txt \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/source-phase2-playbook.md \
  --output OUTPUT_DIR/runtime/prompt-source-phase2.md
```

**2. 生成 orchestrator 调度 prompt：**

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-source-synth-orchestrator.md \
  --var PHASE1_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-source-phase1.md \
  --var PHASE2_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-source-phase2.md \
  --var BRIEF_OUTPUT=OUTPUT_DIR/source-brief.txt \
  --output OUTPUT_DIR/runtime/prompt-source-orchestrator.md
```

**3. 创建 Subagent 并执行：**

```
{{SUBAGENT_NAME}} = SourceSynth
{{MODEL}}           = SUBAGENT_MODEL
{{THINKING_EFFORT}} = SUBAGENT_THINKING_EFFORT
{{PROMPT_PATH}}   = OUTPUT_DIR/runtime/prompt-source-orchestrator.md
```

> subagent 内部会自主渐进：先读 phase1 完成资料提炼 -> 再读 phase2 完成自审 -> FINALIZE

**4. Gate 校验（主 agent 复检）：**

```bash
python SKILL_DIR/scripts/contract_validator.py source-brief OUTPUT_DIR/source-brief.txt
```

> `CURRENT_BRIEF_PATH`（后续步骤用）= `OUTPUT_DIR/source-brief.txt`



## Step 3 大纲（渐进式上下文注入）

> **Subagent 强制**：本步产物必须由 Outline subagent 生成，主 agent 禁止内联生产。
> subagent 内部自主按阶段渐进：大纲编写 -> 严格自审+修复。

**1. 生成阶段 prompt 文件（主 agent 执行）：**

```bash
# Phase 1: 大纲编写
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-outline-phase1.md \
  --var REQUIREMENTS_PATH=OUTPUT_DIR/requirements-interview.txt \
  --var BRIEF_PATH=CURRENT_BRIEF_PATH \
  --var OUTLINE_OUTPUT=OUTPUT_DIR/outline.txt \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/outline-phase1-playbook.md \
  --output OUTPUT_DIR/runtime/prompt-outline-phase1.md

# Phase 2: 严格自审与修复
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-outline-phase2.md \
  --var OUTLINE_OUTPUT=OUTPUT_DIR/outline.txt \
  --var REQUIREMENTS_PATH=OUTPUT_DIR/requirements-interview.txt \
  --var BRIEF_PATH=CURRENT_BRIEF_PATH \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/outline-phase2-playbook.md \
  --output OUTPUT_DIR/runtime/prompt-outline-phase2.md
```

**2. 生成 orchestrator 调度 prompt：**

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-outline-orchestrator.md \
  --var PHASE1_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-outline-phase1.md \
  --var PHASE2_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-outline-phase2.md \
  --var OUTLINE_OUTPUT=OUTPUT_DIR/outline.txt \
  --output OUTPUT_DIR/runtime/prompt-outline-orchestrator.md
```

**3. 创建 Subagent 并执行：**

```
{{SUBAGENT_NAME}} = Outline
{{MODEL}}           = SUBAGENT_MODEL
{{THINKING_EFFORT}} = SUBAGENT_THINKING_EFFORT
{{PROMPT_PATH}}   = OUTPUT_DIR/runtime/prompt-outline-orchestrator.md
```

> subagent 内部会自主渐进：先读 phase1 完成大纲编写 -> 再读 phase2 完成自审修复 -> FINALIZE

**4. Gate 校验（主 agent 复检）：**

```bash
python SKILL_DIR/scripts/contract_validator.py outline OUTPUT_DIR/outline.txt
```

若 validator 未通过，回退 Step 3.01 重新生成 prompt 并**重建新的 Outline subagent**；不要复用已 FINALIZE 的旧 session。

---

## Step 3.5 风格（渐进式上下文注入）

> **Subagent 强制**：本步产物必须由 Style subagent 生成，主 agent 禁止内联生产。
> subagent 内部自主按阶段渐进：约束提炼+风格输出 -> 字段合同自审。

**1. 生成阶段 prompt 文件（主 agent 执行）：**

```bash
# Phase 1: 约束提炼与风格输出
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-style-phase1.md \
  --var REQUIREMENTS_PATH=OUTPUT_DIR/requirements-interview.txt \
  --var OUTLINE_PATH=OUTPUT_DIR/outline.txt \
  --var SKILL_DIR='$SKILL_DIR' \
  --var STYLE_OUTPUT=OUTPUT_DIR/style.json \
  --inject-file STYLE_RUNTIME_RULES=SKILL_DIR/references/styles/runtime-style-rules.md \
  --inject-file STYLE_PRESET_INDEX=SKILL_DIR/references/styles/runtime-style-palette-index.md \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/style-phase1-playbook.md \
  --output OUTPUT_DIR/runtime/prompt-style-phase1.md

# Phase 2: 字段合同自审
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-style-phase2.md \
  --var STYLE_OUTPUT=OUTPUT_DIR/style.json \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/style-phase2-playbook.md \
  --output OUTPUT_DIR/runtime/prompt-style-phase2.md
```

**2. 生成 orchestrator 调度 prompt：**

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/tpl-style-orchestrator.md \
  --var PHASE1_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-style-phase1.md \
  --var PHASE2_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-style-phase2.md \
  --var STYLE_OUTPUT=OUTPUT_DIR/style.json \
  --output OUTPUT_DIR/runtime/prompt-style-orchestrator.md
```

**3. 创建 Subagent 并执行：**

```
{{SUBAGENT_NAME}} = Style
{{MODEL}}           = SUBAGENT_MODEL
{{THINKING_EFFORT}} = SUBAGENT_THINKING_EFFORT
{{PROMPT_PATH}}   = OUTPUT_DIR/runtime/prompt-style-orchestrator.md
```

> subagent 内部会自主渐进：先读 phase1 完成风格决策 -> 再读 phase2 完成自审 -> FINALIZE

**4. Gate 校验（主 agent 复检）：**

```bash
python SKILL_DIR/scripts/contract_validator.py style OUTPUT_DIR/style.json
```

若 validator 未通过，回退 Step 3.5.01 重新生成 prompt 并**重建新的 Style subagent**；不要复用已 FINALIZE 的旧 session。

---

## Step 4 单页生产（渐进式上下文注入）

> **统一执行后端**：所有环境统一使用 orchestrator 渐进式披露。
> subagent 内部自主按阶段读取 prompt，主 agent 只负责生成 prompt + 创建 subagent + 回收校验。
> 若用户开启人工审计断点，则主 agent 仍先生成同一套 runtime prompt，再按需要创建阶段型 PageAgent 或 `PagePatchAgent-N`。

---

### 4.1 生成 Planning 快照 + 三份阶段 prompt 文件

先生成 planning 阶段会直接用到的 runtime 快照，再依次执行三个 harness 命令（顺序不可调换）：

**4A.0 Planning 图片清单快照：**

```bash
python SKILL_DIR/scripts/resource_loader.py images \
  --images-dir OUTPUT_DIR/images \
  --output OUTPUT_DIR/runtime/page-images-N.md
```

**4A.1 Planning 菜单快照：**

```bash
python SKILL_DIR/scripts/resource_loader.py menu \
  --refs-dir SKILL_DIR/references \
  --output OUTPUT_DIR/runtime/page-planning-menu-N.md
```

**4A. Planning prompt：**

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/step4/tpl-page-planning.md \
  --var PAGE_NUM=N \
  --var TOTAL_PAGES=TOTAL \
  --var REQUIREMENTS_PATH=OUTPUT_DIR/requirements-interview.txt \
  --var OUTLINE_PATH=OUTPUT_DIR/outline.txt \
  --var BRIEF_PATH=CURRENT_BRIEF_PATH \
  --var STYLE_PATH=OUTPUT_DIR/style.json \
  --var IMAGES_DIR=OUTPUT_DIR/images \
  --var IMAGE_INVENTORY_PATH=OUTPUT_DIR/runtime/page-images-N.md \
  --var RESOURCE_MENU_PATH=OUTPUT_DIR/runtime/page-planning-menu-N.md \
  --var PLANNING_RUNTIME_COPY_PATH=OUTPUT_DIR/runtime/page-planning-output-N.json \
  --var PLANNING_VALIDATOR_REPORT_PATH=OUTPUT_DIR/runtime/page-planning-validator-N.json \
  --var PLANNING_OUTPUT=OUTPUT_DIR/planning/planningN.json \
  --var SUBAGENT_LOG_PATH=OUTPUT_DIR/runtime/page-agent-N.log \
  --var SUBAGENT_NAME=PageAgent-N \
  --var SKILL_DIR='$SKILL_DIR' \
  --var REFS_DIR='$SKILL_DIR/references' \
  --inject-file PRINCIPLES_CHEATSHEET=SKILL_DIR/references/principles/design-principles-cheatsheet.md \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/step4/page-planning-playbook.md \
  --output OUTPUT_DIR/runtime/prompt-page-planning-N.md
```

**4B. Spec prompt：**

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/step4/tpl-page-spec.md \
  --var PAGE_NUM=N \
  --var TOTAL_PAGES=TOTAL \
  --var PLANNING_OUTPUT=OUTPUT_DIR/planning/planningN.json \
  --var SPEC_OUTPUT=OUTPUT_DIR/specs/slide-N.spec.json \
  --var IMAGES_DIR=OUTPUT_DIR/images \
  --var IMAGE_INVENTORY_PATH=OUTPUT_DIR/runtime/page-images-N.md \
  --var SPEC_RESOLVE_PATH=OUTPUT_DIR/runtime/page-spec-resolve-N.md \
  --var STYLE_PATH=OUTPUT_DIR/style.json \
  --var SUBAGENT_LOG_PATH=OUTPUT_DIR/runtime/page-agent-N.log \
  --var SUBAGENT_NAME=PageAgent-N \
  --var SKILL_DIR='$SKILL_DIR' \
  --var REFS_DIR='$SKILL_DIR/references' \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/step4/page-spec-playbook.md \
  --inject-file SPEC_GUIDE=SKILL_DIR/references/spec-guide.md \
  --output OUTPUT_DIR/runtime/prompt-page-spec-N.md
```

**4C. Build & Review prompt：**

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/step4/tpl-page-review.md \
  --var PAGE_NUM=N \
  --var TOTAL_PAGES=TOTAL \
  --var PLANNING_OUTPUT=OUTPUT_DIR/planning/planningN.json \
  --var SPEC_OUTPUT=OUTPUT_DIR/specs/slide-N.spec.json \
  --var SLIDE_PPTX_OUTPUT=OUTPUT_DIR/build/slide-N.pptx \
  --var PNG_DIR=OUTPUT_DIR/png/page-N \
  --var PNG_OUTPUT=OUTPUT_DIR/png/page-N/slide-01.png \
  --var COM_QA_REPORT_PATH=OUTPUT_DIR/runtime/page-com-qa-N.json \
  --var REVIEW_DIR=OUTPUT_DIR/review \
  --var REVIEW_RUNTIME_PNG_PATH=OUTPUT_DIR/runtime/page-review-output-N.png \
  --var STYLE_PATH=OUTPUT_DIR/style.json \
  --var SUBAGENT_LOG_PATH=OUTPUT_DIR/runtime/page-agent-N.log \
  --var SUBAGENT_NAME=PageAgent-N \
  --var SKILL_DIR='$SKILL_DIR' \
  --inject-file PRINCIPLES_CHEATSHEET=SKILL_DIR/references/principles/design-principles-cheatsheet.md \
  --inject-file PLAYBOOK=SKILL_DIR/references/playbooks/step4/page-review-playbook.md \
  --inject-file FAILURE_MODES=SKILL_DIR/references/principles/runtime-failure-modes.md \
  --output OUTPUT_DIR/runtime/prompt-page-review-N.md
```

> 单页 build 的 PNG 导出目录按页隔离（`png/page-N/`），COM 导出的单页文件名固定为 `slide-01.png`。

---

### 4.2 生成 orchestrator 调度 prompt

```bash
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/step4/tpl-page-orchestrator.md \
  --var PAGE_NUM=N \
  --var TOTAL_PAGES=TOTAL \
  --var PLANNING_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-page-planning-N.md \
  --var SPEC_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-page-spec-N.md \
  --var REVIEW_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-page-review-N.md \
  --var PLANNING_OUTPUT=OUTPUT_DIR/planning/planningN.json \
  --var SPEC_OUTPUT=OUTPUT_DIR/specs/slide-N.spec.json \
  --var SLIDE_PPTX_OUTPUT=OUTPUT_DIR/build/slide-N.pptx \
  --var PNG_OUTPUT=OUTPUT_DIR/png/page-N/slide-01.png \
  --var SUBAGENT_LOG_PATH=OUTPUT_DIR/runtime/page-agent-N.log \
  --var SUBAGENT_NAME=PageAgent-N \
  --var SKILL_DIR='$SKILL_DIR' \
  --output OUTPUT_DIR/runtime/prompt-page-orchestrator-N.md
```

---

### 4.3 创建 PageAgent-N 并执行

回查《Subagent 操作手册》取出调用模板，替换变量后**显式输出到对话**再执行：
```
{{SUBAGENT_NAME}} = PageAgent-N
{{MODEL}}           = SUBAGENT_MODEL
{{THINKING_EFFORT}} = SUBAGENT_THINKING_EFFORT
{{PROMPT_PATH}}   = OUTPUT_DIR/runtime/prompt-page-orchestrator-N.md
```
> subagent 是完全隔离的：它只能看到 orchestrator prompt 的内容，内部按 orchestrator 指示自主渐进读取各阶段 prompt。

> subagent 内部会按 orchestrator 的指示自主渐进：
> 1. 先读 planning prompt -> 完成策划 -> 产出 planningN.json
> 2. 自主读 spec prompt -> 完成原生设计稿 -> 产出 slide-N.spec.json（过 spec Gate）
> 3. 自主读 review prompt -> build + COM 导出 + 图审修复（保底 2 轮）-> 产出 slide-N.pptx + slide-01.png
> 4. P0+P1 清零 + COM QA 退出码 0 + spec Gate 通过后 FINALIZE

---

### 4.3A 可选：人工审计断点 / Step 4 外挂返工

当 Step 0 已记录 `manual_audit_mode != off`，或用户在运行中明确要求“看某张图 / 用 runtime / 从某节点重开”时，主 agent 应切到这一支。

**适用场景：**

- 用户想先看 `planningN.json` 再决定是否继续
- 用户想看当前 `slide-N.spec.json` 或最终 `png/page-N/slide-01.png`
- 用户点名某张 `review/roundX/slide-N.png`
- 用户给出追加 prompt，要求从 `planning` / `spec` / `review` 某个节点重新执行

**1. 生成外挂 orchestrator prompt：**

```bash
# 1a. 先生成返工请求并校验
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/step4/tpl-page-audit-request.md \
  --var PAGE_NUM=N \
  --var START_STAGE=spec \
  --var END_STAGE=review \
  --var USER_AUDIT_REQUEST="用户追加的图审或改稿要求（压成一行）" \
  --var TARGET_ASSET_PATH=OUTPUT_DIR/review/round2/slide-N.png \
  --var RUNTIME_CONTEXT_PATHS="OUTPUT_DIR/runtime/prompt-page-spec-N.md; OUTPUT_DIR/runtime/prompt-page-review-N.md; OUTPUT_DIR/runtime/page-spec-resolve-N.md" \
  --var PLANNING_OUTPUT=OUTPUT_DIR/planning/planningN.json \
  --var SPEC_OUTPUT=OUTPUT_DIR/specs/slide-N.spec.json \
  --var PNG_OUTPUT=OUTPUT_DIR/png/page-N/slide-01.png \
  --output OUTPUT_DIR/runtime/page-audit-request-N.txt

python SKILL_DIR/scripts/contract_validator.py page-audit-request OUTPUT_DIR/runtime/page-audit-request-N.txt --base-dir OUTPUT_DIR

# 1b. 再生成外挂 orchestrator prompt
python SKILL_DIR/scripts/prompt_harness.py \
  --template SKILL_DIR/references/prompts/step4/tpl-page-breakpoint-orchestrator.md \
  --var PAGE_NUM=N \
  --var TOTAL_PAGES=TOTAL \
  --var AUDIT_REQUEST_PATH=OUTPUT_DIR/runtime/page-audit-request-N.txt \
  --var START_STAGE=spec \
  --var END_STAGE=review \
  --var PLANNING_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-page-planning-N.md \
  --var SPEC_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-page-spec-N.md \
  --var REVIEW_PROMPT_PATH=OUTPUT_DIR/runtime/prompt-page-review-N.md \
  --var PLANNING_OUTPUT=OUTPUT_DIR/planning/planningN.json \
  --var SPEC_OUTPUT=OUTPUT_DIR/specs/slide-N.spec.json \
  --var SLIDE_PPTX_OUTPUT=OUTPUT_DIR/build/slide-N.pptx \
  --var PNG_OUTPUT=OUTPUT_DIR/png/page-N/slide-01.png \
  --var SUBAGENT_LOG_PATH=OUTPUT_DIR/runtime/page-patch-agent-N.log \
  --var SUBAGENT_NAME=PagePatchAgent-N \
  --var SKILL_DIR='$SKILL_DIR' \
  --var TARGET_ASSET_PATH=OUTPUT_DIR/review/round2/slide-N.png \
  --var RUNTIME_CONTEXT_PATHS="OUTPUT_DIR/runtime/prompt-page-spec-N.md; OUTPUT_DIR/runtime/prompt-page-review-N.md" \
  --var USER_AUDIT_REQUEST="用户追加的图审或改稿要求" \
  --output OUTPUT_DIR/runtime/prompt-page-breakpoint-N.md
```

> 若当前没有点名图片或额外 runtime 文件，将 `TARGET_ASSET_PATH` 或 `RUNTIME_CONTEXT_PATHS` 填成 `none`。

**2. 创建 `PagePatchAgent-N` 并执行：**

```
{{SUBAGENT_NAME}} = PagePatchAgent-N
{{MODEL}}           = SUBAGENT_MODEL
{{THINKING_EFFORT}} = SUBAGENT_THINKING_EFFORT
{{PROMPT_PATH}}   = OUTPUT_DIR/runtime/prompt-page-breakpoint-N.md
```

**3. 起点规则：**

- `START_STAGE=planning`：重做策划，并继续跑 `spec -> review`
- `START_STAGE=spec`：复用现有 planning，重做 `spec -> review`
- `START_STAGE=review`：复用现有 planning + spec，直接进 build + 图审修复循环

**4. 终点规则：**

- `END_STAGE=planning`：只产出更新后的 `planningN.json`，用于中间断点确认
- `END_STAGE=spec`：产出更新后的 `slide-N.spec.json`（已过 Gate），用于中间断点确认
- `END_STAGE=review`：产出更新后的 `slide-N.pptx` + PNG，随后仍要进入 4.4 的整页终检

---

### 4.4 回收 FINALIZE — 主 agent 整页终检

**第 1 步：产物存在性 + 合同校验**

```bash
test -s OUTPUT_DIR/planning/planningN.json
python SKILL_DIR/scripts/planning_validator.py OUTPUT_DIR/planning --refs SKILL_DIR/references --page N
test -s OUTPUT_DIR/specs/slide-N.spec.json
python SKILL_DIR/scripts/spec_validator.py spec OUTPUT_DIR/specs/slide-N.spec.json --style OUTPUT_DIR/style.json
test -s OUTPUT_DIR/build/slide-N.pptx
test -s OUTPUT_DIR/png/page-N/slide-01.png
```

**第 2 步：COM 结构断言（第一道过滤器）**

```bash
powershell -ExecutionPolicy Bypass -File SKILL_DIR/scripts/ppt_export.ps1 -Mode qa -InputFile OUTPUT_DIR/build/slide-N.pptx -Out OUTPUT_DIR/runtime/page-com-qa-N.json
# exit=1 -> 致命缺陷（文字溢出/出画布），直接重跑或走 PagePatchAgent
```

**第 3 步（核心质量关卡）：主 agent 亲自看截图**

> 这是整个质量体系的最终防线。COM QA 只能抓硬伤，排版质量、内容完整性、视觉和谐度必须由主 agent 亲眼确认。

1. 用当前宿主可用的图像查看能力查看 `OUTPUT_DIR/png/page-N/slide-01.png`
2. 重点关注：
   - 文字是否可读、排版是否正常（换行异常、文字挤压等）
   - 卡片内容是否完整（对照 subagent FINALIZE 中的 planning 卡片列表）
   - 整体视觉是否和谐（不像毛坯房、不像默认模板）
   - 密度是否符合 density_contract（不空不爆）
3. 如果看到明显问题 -> 标记该页失败，触发重跑

**判定规则**：若 COM QA `exit=1`、spec Gate 不通过，或主 agent 看图发现明显问题，则本页视为失败。

---

**触发条件（任一成立）：**
- `planningN.json` 不存在、为空或 `planning_validator.py` 不通过
- `slide-N.spec.json` 不存在、为空或 `spec_validator.py` 不通过
- `build/slide-N.pptx` 或 `png/page-N/slide-01.png` 不存在或为空
- COM QA（`ppt_export.ps1 -Mode qa`）退出码为 1
- 主 agent 亲自看图发现明显视觉问题

**无论同对话还是跨对话，统一两步走：**

**第一步：侦查** -- 读 `outline.txt` 确认总页数，遍历所有页收集失败页列表：

```bash
# 对每页 1..N：
test -s OUTPUT_DIR/planning/planningN.json && \
test -s OUTPUT_DIR/specs/slide-N.spec.json && \
test -s OUTPUT_DIR/build/slide-N.pptx && \
test -s OUTPUT_DIR/png/page-N/slide-01.png && \
python SKILL_DIR/scripts/planning_validator.py OUTPUT_DIR/planning --refs SKILL_DIR/references --page N && \
python SKILL_DIR/scripts/spec_validator.py spec OUTPUT_DIR/specs/slide-N.spec.json --style OUTPUT_DIR/style.json && \
powershell -ExecutionPolicy Bypass -File SKILL_DIR/scripts/ppt_export.ps1 -Mode qa -InputFile OUTPUT_DIR/build/slide-N.pptx -Out OUTPUT_DIR/runtime/page-com-qa-N.json
# 任一 exit!=0 -> 加入失败页列表
```

> 自动探测通过后，主 agent 仍需重新看图确认；自动 QA 不是人工审美检查的替代品。

**第二步：并行重跑** -- 收集完毕，一次性并行启动所有失败页（不串行逐页；注意 COM 导出会在全局队列上自动串行，无需人为错峰）：

```bash
# 对失败页列表 [N1, N2, ...] 中每页，清理旧产物及可能的 review 图片残留：
python -c "import os, glob; [os.remove(p) for p in ['OUTPUT_DIR/planning/planningN.json','OUTPUT_DIR/specs/slide-N.spec.json','OUTPUT_DIR/build/slide-N.pptx','OUTPUT_DIR/png/page-N/slide-01.png'] + glob.glob('OUTPUT_DIR/review/round*/slide-N.png') if os.path.exists(p)]"
# 从 Step 4 的 prompt 生成阶段开始重跑：先生成 prompt，再创建 PageAgent-N，随后 RUN orchestrator
```

> session 一律视为不可续接（subagent 死亡=上下文全无），整页从 4.1 开始重跑。
> 跨对话恢复时旧 session 全部失效，逻辑相同。

---

## Step 5 导出（原生单管线）

执行管线：

```bash
# 1. 汇编：所有过审 spec -> 一份原生 presentation.pptx（单次 PptxGenJS 构建，主题/字体全局一致）
node SKILL_DIR/scripts/deck_assembler.js OUTPUT_DIR/specs --style OUTPUT_DIR/style.json -o OUTPUT_DIR/presentation.pptx

# 2. COM 收尾：打开洁净度检查 + 全 deck PNG 预览 + PDF（一次 PowerPoint 会话完成）
powershell -ExecutionPolicy Bypass -File SKILL_DIR/scripts/ppt_export.ps1 -Mode all \
  -InputFile OUTPUT_DIR/presentation.pptx -OutDir OUTPUT_DIR/png/deck -Out OUTPUT_DIR/presentation.pdf

# 3. 预览页：用 COM 导出的 PNG 生成网格 preview.html
node SKILL_DIR/scripts/deck_assembler.js OUTPUT_DIR/specs --style OUTPUT_DIR/style.json \
  -o OUTPUT_DIR/presentation.pptx --preview OUTPUT_DIR/preview.html --png-dir OUTPUT_DIR/png/deck

# 4. 交付清单
# 主 agent 按以下 schema 写入 delivery-manifest.json
```

> 导出失败只回退导出（重跑上面对应命令），不回退内容生产。`-Mode all` 中的 check 失败（打不开/0 页）说明汇编产物损坏——回到汇编排查，不要手改 pptx。

**delivery-manifest.json 必填 schema**：

```json
{
  "run_id": "RUN_ID（与 OUTPUT_DIR 对应）",
  "generated_at": "ISO 8601 时间戳（如 2026-04-01T14:30:00Z）",
  "summary": {
    "total_pages": 页数（正整数）
  },
  "artifacts": {
    "preview_html": "preview.html（相对于 OUTPUT_DIR 的路径）",
    "presentation_pptx": "presentation.pptx",
    "presentation_pdf": "presentation.pdf"
  },
  "pages": [
    { "page": 1, "planning": "planning/planning1.json", "spec": "specs/slide-1.spec.json", "png": "png/deck/slide-01.png" }
  ]
}
```

> `run_id`、`generated_at`、`artifacts`（含三个路径）为 validator 强制校验字段；`summary` 和 `pages` 建议填写。

Gate 校验：

```bash
python SKILL_DIR/scripts/contract_validator.py delivery-manifest OUTPUT_DIR/delivery-manifest.json --base-dir OUTPUT_DIR
```

---

## 资源路由

菜单（planning 阶段）：

```bash
python SKILL_DIR/scripts/resource_loader.py menu \
  --refs-dir SKILL_DIR/references \
  --output OUTPUT_DIR/runtime/page-planning-menu-N.md
```

解析（spec 阶段）：

```bash
python SKILL_DIR/scripts/resource_loader.py resolve --refs-dir SKILL_DIR/references --planning OUTPUT_DIR/planning/planningN.json
```

图片清单（planning / spec 阶段）：

```bash
python SKILL_DIR/scripts/resource_loader.py images --images-dir OUTPUT_DIR/images
```

---

## 里程碑总验收

```bash
python SKILL_DIR/scripts/milestone_check.py <stage> --output-dir OUTPUT_DIR
```

---

## 合同校验器 contract-type 列表

`interview` / `requirements-interview` / `source-brief` / `outline` / `style` / `images` / `page-review` / `page-audit-request` / `delivery-manifest`

通用格式：

```bash
python SKILL_DIR/scripts/contract_validator.py <contract-type> <target-file> [--base-dir OUTPUT_DIR]
```

---

## 结构质量断言（COM QA，替代 HTML 时代的 visual_qa.py）

> Step 4 回收后的第一道自动过滤器。用 PowerPoint 真实排版引擎实测：文字溢出（TextFrame2 bounds）、
> 出画布 shape。真正的视觉质量判断由主 agent 亲自看图完成。

单页 / 整 deck 通用：

```bash
powershell -ExecutionPolicy Bypass -File SKILL_DIR/scripts/ppt_export.ps1 -Mode qa -InputFile <pptx> -Out <report.json>
```

退出码：`0` = 无致命项、`1` = FAIL（有 FATAL finding，报告里逐条给出 slide/shape/差值，直接映射回 spec 修复）

依赖：Windows + 桌面版 PowerPoint（交互式会话）。所有 COM 调用共用全局队列，并行页会自动串行。
