#!/usr/bin/env python3
"""spec_validator.py — Gate for slide-N.spec.json and native style token files.

This script IS the executable schema truth for the native pipeline (the same
role planning_validator.py plays for planningN.json). Dependency-free stdlib.

Usage:
    python3 spec_validator.py spec  <slide-N.spec.json> --style <style.json>
    python3 spec_validator.py style <style.json>

Exit 0 = gate passes. Exit 1 = failures listed, each naming its fix.
Warnings do not block the gate.
"""

import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULTS = json.load(open(os.path.join(HERE, "..", "schema", "defaults.json"), encoding="utf-8"))

CANVAS_W = DEFAULTS["canvas"]["w"]
CANVAS_H = DEFAULTS["canvas"]["h"]

PAGE_TYPES = {"cover", "toc", "section", "content", "end"}
ELEMENT_TYPES = {"text", "bullets", "card", "kpi", "chart", "table", "shape", "image"}
CHART_TYPES = {"bar", "column", "bar_stacked", "column_stacked", "line", "area", "pie", "doughnut", "radar"}
CARD_STYLES = {"filled", "outline", "accent", "elevated", "tint"}
SHAPE_KINDS = {"rect", "roundRect", "oval", "line"}
IMAGE_POLICIES = {"none", "manual_slot", "decorate", "generate"}

CONTRACT_KEYS = [
    "deck_bias", "density_label", "page_lower_bound", "page_upper_bound",
    "max_cards", "max_charts", "min_body_font_pt", "max_lines_per_card",
    "image_policy", "decoration_budget", "overflow_strategy",
]

REQUIRED_COLOR_TOKENS = [
    "bg_primary", "bg_secondary", "card_bg", "card_border",
    "text_primary", "text_secondary", "accent_1", "on_accent", "grid",
]

# Fonts that ship with Windows / Office and render identically in PowerPoint COM QA.
WINDOWS_SAFE_FONTS = {
    "Microsoft YaHei", "SimSun", "SimHei", "DengXian",
    "Segoe UI", "Calibri", "Cambria", "Arial", "Times New Roman", "Courier New",
}


class Report:
    def __init__(self):
        self.failures = []
        self.warnings = []

    def fail(self, msg, fix):
        self.failures.append((msg, fix))

    def warn(self, msg):
        self.warnings.append(msg)

    def dump(self, label):
        for msg in self.warnings:
            print(f"WARN  {msg}")
        if self.failures:
            print(f"\n{label}: {len(self.failures)} failure(s)")
            for msg, fix in self.failures:
                print(f"FAIL  {msg}\n      FIX: {fix}")
            return 1
        print(f"{label}: PASSED" + (f" ({len(self.warnings)} warning(s))" if self.warnings else ""))
        return 0


def load_json(path, rep, what):
    if not os.path.exists(path):
        rep.fail(f"{what} not found: {path}", "check the path")
        return None
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        rep.fail(f"{what} is not valid JSON: {e}", "fix the JSON syntax at the reported position")
        return None


def norm_hex(value):
    v = str(value).lstrip("#").upper()
    if len(v) == 6 and all(c in "0123456789ABCDEF" for c in v):
        return v
    return None


def color_resolves(ref, style):
    """Mirror of render_core.resolveColor: token name or 6-digit hex."""
    if ref is None:
        return True
    colors = style.get("colors", {})
    if ref in colors:
        return norm_hex(colors[ref]) is not None
    return norm_hex(ref) is not None


# --------------------------------------------------------------------------
# style mode
# --------------------------------------------------------------------------

def validate_style(path):
    rep = Report()
    style = load_json(path, rep, "style file")
    if style is None:
        return rep.dump("style gate")

    fonts = style.get("fonts") or {}
    for key in ("heading", "body"):
        name = fonts.get(key)
        if not name or not isinstance(name, str):
            rep.fail(f'fonts.{key} missing', f'add "fonts": {{"{key}": "Microsoft YaHei", ...}}')
        elif name not in WINDOWS_SAFE_FONTS:
            rep.warn(f'fonts.{key} "{name}" is not on the Windows-safe list {sorted(WINDOWS_SAFE_FONTS)} — COM QA fidelity is only guaranteed for safe fonts')

    colors = style.get("colors") or {}
    for token in REQUIRED_COLOR_TOKENS:
        if token not in colors:
            rep.fail(f'colors.{token} missing', f'add "{token}" to colors (6-digit hex, no #)')
        elif norm_hex(colors[token]) is None:
            rep.fail(f'colors.{token} = "{colors[token]}" is not 6-digit hex',
                     "use exactly 6 hex digits without # — 8-digit or #-prefixed hex corrupts the pptx")
    for token, val in colors.items():
        if norm_hex(val) is None:
            rep.fail(f'colors.{token} = "{val}" is not 6-digit hex', "use exactly 6 hex digits without #")

    for i, entry in enumerate(style.get("chart_palette") or []):
        if not color_resolves(entry, style):
            rep.fail(f'chart_palette[{i}] = "{entry}" does not resolve', "use a colors.* token name or 6-digit hex")
    if not style.get("chart_palette"):
        rep.warn("chart_palette missing — charts will use pptxgenjs's dated default palette")

    recipes = style.get("card_recipes") or {}
    for name in CARD_STYLES:
        r = recipes.get(name)
        if r is None:
            rep.fail(f'card_recipes.{name} missing', f'define all five recipes: {sorted(CARD_STYLES)}')
            continue
        for field in ("title_color", "text_color"):
            if field not in r or not color_resolves(r[field], style):
                rep.fail(f'card_recipes.{name}.{field} missing or unresolvable', "point it at a colors.* token")
        if r.get("fill") is not None and not color_resolves(r["fill"], style):
            rep.fail(f'card_recipes.{name}.fill = "{r["fill"]}" does not resolve', "use a token or 6-digit hex, or null for no fill")
        line = r.get("line")
        if line is not None and not color_resolves(line.get("color"), style):
            rep.fail(f'card_recipes.{name}.line.color does not resolve', "use a token or 6-digit hex")

    return rep.dump("style gate")


# --------------------------------------------------------------------------
# spec mode
# --------------------------------------------------------------------------

def check_frame(el, eid, rep, allow_bleed):
    f = el.get("frame")
    if not isinstance(f, dict) or any(not isinstance(f.get(k), (int, float)) for k in ("x", "y", "w", "h")):
        rep.fail(f'{eid}: frame must be {{"x","y","w","h"}} in inches (numbers)',
                 'add e.g. "frame": {"x": 0.5, "y": 1.7, "w": 4.0, "h": 2.2}')
        return None
    x, y, w, h = f["x"], f["y"], f["w"], f["h"]
    if w <= 0 or h <= 0:
        rep.fail(f"{eid}: frame w/h must be positive", "fix the frame dimensions")
        return f
    eps = 0.001
    if x < -eps or y < -eps or x + w > CANVAS_W + eps or y + h > CANVAS_H + eps:
        rep.fail(f"{eid}: frame ({x},{y},{w},{h}) leaves the {CANVAS_W}x{CANVAS_H} in canvas",
                 "pptxgenjs writes off-canvas shapes without clamping — they are simply invisible; move the frame inside the slide")
        return f
    margin = DEFAULTS["min_edge_margin"]
    if not allow_bleed and (x < margin or y < margin or CANVAS_W - (x + w) < margin or CANVAS_H - (y + h) < margin):
        rep.warn(f"{eid}: frame is closer than {margin}in to a slide edge — intentional full-bleed is fine, accidental crowding is not")
    return f


def collect_color_refs(el):
    refs = []
    for key in ("color", "label_color", "title_color", "body_color", "accent_color", "fill", "header_fill", "background"):
        if el.get(key) is not None:
            refs.append((key, el[key]))
    line = el.get("line")
    if isinstance(line, dict) and line.get("color") is not None:
        refs.append(("line.color", line["color"]))
    for i, run in enumerate(el.get("runs") or []):
        if isinstance(run, dict) and run.get("color") is not None:
            refs.append((f"runs[{i}].color", run["color"]))
    return refs


def body_font_size(el):
    """Effective body font size the builder will use (defaults mirrored from defaults.json)."""
    t = el.get("type")
    if t == "text":
        return el.get("size", DEFAULTS["text_size"])
    if t == "bullets":
        return el.get("size", DEFAULTS["bullet_size"])
    if t == "card":
        return el.get("body_size", DEFAULTS["card_body_size"]) if el.get("body") else None
    if t == "kpi":
        return el.get("label_size", DEFAULTS["kpi_label_size"])
    if t == "table":
        return el.get("font_size", DEFAULTS["table_font_size"])
    return None


def validate_spec(spec_path, style_path):
    rep = Report()
    spec = load_json(spec_path, rep, "spec file")
    style = load_json(style_path, rep, "style file") if style_path else None
    if spec is None or style is None:
        return rep.dump("spec gate")

    # ---- top level ----
    if spec.get("spec_version") != "1.0":
        rep.fail(f'spec_version = {spec.get("spec_version")!r}', 'set "spec_version": "1.0"')
    if not isinstance(spec.get("page"), int) or spec["page"] < 1:
        rep.fail("page must be a positive integer", 'set "page": N matching the outline page number')
    if spec.get("page_type") not in PAGE_TYPES:
        rep.fail(f'page_type = {spec.get("page_type")!r}', f"use one of {sorted(PAGE_TYPES)}")
    if spec.get("background") is not None and not color_resolves(spec["background"], style):
        rep.fail(f'background "{spec["background"]}" does not resolve', "use a colors.* token or 6-digit hex")
    if not isinstance(spec.get("elements"), list):
        rep.fail("elements must be a list", 'add "elements": [] (may be empty for cover/section pages)')
        return rep.dump("spec gate")

    # ---- density contract ----
    contract = spec.get("density_contract")
    if not isinstance(contract, dict):
        rep.fail("density_contract missing",
                 "copy the frozen contract from planningN.json — the spec must carry it so this gate can enforce it")
        contract = {}
    else:
        for key in CONTRACT_KEYS:
            if key not in contract:
                rep.fail(f"density_contract.{key} missing", f"copy {key} from planningN.json (required by SKILL 6.8)")
        if contract.get("image_policy") not in IMAGE_POLICIES and "image_policy" in contract:
            rep.fail(f'density_contract.image_policy = {contract.get("image_policy")!r}', f"use one of {sorted(IMAGE_POLICIES)}")

    min_font = contract.get("min_body_font_pt", 0) or 0
    max_cards = contract.get("max_cards")
    max_charts = contract.get("max_charts")
    max_lines = contract.get("max_lines_per_card")
    decoration_budget = contract.get("decoration_budget")
    image_policy = contract.get("image_policy", "none")

    # ---- per element ----
    counts = {"card": 0, "chart": 0, "kpi": 0, "shape": 0, "image": 0, "table": 0, "text": 0, "bullets": 0}
    accent_cards = 0
    elevated_cards = 0

    for idx, el in enumerate(spec["elements"]):
        eid = f'elements[{idx}] ({el.get("id") or el.get("type") or "?"})'
        t = el.get("type")
        if t not in ELEMENT_TYPES:
            rep.fail(f"{eid}: type {t!r} unknown", f"use one of {sorted(ELEMENT_TYPES)}")
            continue
        counts[t] += 1
        check_frame(el, eid, rep, allow_bleed=(t in ("shape", "image")))

        for field, ref in collect_color_refs(el):
            if not color_resolves(ref, style):
                rep.fail(f'{eid}: {field} = "{ref}" does not resolve against {os.path.basename(style_path)}',
                         "use a colors.* token name or 6-digit hex without #")

        if t == "text":
            if el.get("text") is None and not el.get("runs"):
                rep.fail(f"{eid}: needs text or runs", 'add "text": "..." or a "runs" array')
        elif t == "bullets":
            items = el.get("items")
            if not isinstance(items, list) or not items:
                rep.fail(f"{eid}: items must be a non-empty list", 'add "items": ["...", ...]')
        elif t == "card":
            if el.get("card_style", "filled") not in CARD_STYLES:
                rep.fail(f'{eid}: card_style {el.get("card_style")!r}', f"use one of {sorted(CARD_STYLES)}")
            if el.get("card_style") == "accent":
                accent_cards += 1
            if el.get("card_style") == "elevated":
                elevated_cards += 1
            body = el.get("body") or []
            if max_lines is not None and len(body) > max_lines:
                rep.fail(f"{eid}: {len(body)} body lines > max_lines_per_card {max_lines}",
                         "trim the card body or split the content — do not shrink the font below contract instead")
            if not el.get("title") and not body:
                rep.fail(f"{eid}: card has neither title nor body", "give the card content or remove it")
        elif t == "kpi":
            if el.get("value") in (None, ""):
                rep.fail(f"{eid}: kpi needs a value", 'add "value": "87%"')
        elif t == "chart":
            if el.get("chart_type") not in CHART_TYPES:
                rep.fail(f'{eid}: chart_type {el.get("chart_type")!r} has no native PowerPoint form',
                         f"use one of {sorted(CHART_TYPES)}; treemap/funnel/sankey are not chartable natively — restructure as bars or a table")
            cats = el.get("categories") or []
            series = el.get("series") or []
            if not cats:
                rep.fail(f"{eid}: categories empty", 'add "categories": ["2023", ...]')
            if not series:
                rep.fail(f"{eid}: series empty", 'add "series": [{"name": "...", "values": [...]}]')
            for si, s in enumerate(series):
                vals = s.get("values")
                if not isinstance(vals, list) or any(not isinstance(v, (int, float)) for v in (vals or [])):
                    rep.fail(f"{eid}: series[{si}].values must be numbers", "supply numeric values only")
                elif cats and len(vals) != len(cats):
                    rep.fail(f"{eid}: series[{si}] has {len(vals)} values for {len(cats)} categories",
                             "make every series exactly as long as categories")
        elif t == "table":
            rows = el.get("rows")
            if not isinstance(rows, list) or not rows or any(not isinstance(r, list) for r in rows):
                rep.fail(f"{eid}: rows must be a non-empty list of lists", 'add "rows": [["h1","h2"],["a","b"]]')
            elif len({len(r) for r in rows}) > 1:
                rep.fail(f"{eid}: rows are ragged (differing column counts)", "pad every row to the same length")
        elif t == "shape":
            if el.get("shape", "rect") not in SHAPE_KINDS:
                rep.fail(f'{eid}: shape {el.get("shape")!r}', f"use one of {sorted(SHAPE_KINDS)}")
        elif t == "image":
            if not el.get("path"):
                rep.fail(f"{eid}: image needs a path", 'add "path": "assets/..."')
            if image_policy == "none":
                rep.fail(f"{eid}: image element but density_contract.image_policy is 'none'",
                         "remove the image or go back to planning to change the image policy — the spec may not override the contract")

        # min font enforcement (captions exempt but floored at 8pt)
        size = body_font_size(el)
        if size is not None:
            if el.get("role") == "caption":
                if size < 8:
                    rep.fail(f"{eid}: caption font {size}pt < 8pt absolute floor", "captions may be small but must stay legible")
            elif min_font and size < min_font:
                rep.fail(f"{eid}: effective font {size}pt < density_contract.min_body_font_pt {min_font}pt",
                         'raise the size, or mark true source/caption lines with "role": "caption"')

    # ---- page-level budgets ----
    if max_cards is not None and counts["card"] > max_cards:
        rep.fail(f'{counts["card"]} cards > max_cards {max_cards}',
                 "merge or drop cards, or roll back to planning to renegotiate the budget")
    if max_charts is not None and counts["chart"] > max_charts:
        rep.fail(f'{counts["chart"]} charts > max_charts {max_charts}',
                 "drop a chart or roll back to planning")
    if decoration_budget is not None and counts["shape"] > decoration_budget:
        rep.fail(f'{counts["shape"]} decoration shapes > decoration_budget {decoration_budget}',
                 "remove decorative shapes — the budget is part of the frozen contract")
    if accent_cards > 1:
        rep.fail(f"{accent_cards} accent cards on one page", "one accent card max — two spotlights equal none")
    if elevated_cards > 1:
        rep.fail(f"{elevated_cards} elevated cards on one page", "one elevated card max")

    anchors = counts["card"] + counts["chart"] + counts["kpi"] + counts["table"] + counts["bullets"]
    lo, hi = contract.get("page_lower_bound"), contract.get("page_upper_bound")
    if spec.get("page_type") == "content" and isinstance(lo, int) and isinstance(hi, int):
        if anchors < lo:
            rep.warn(f"{anchors} content anchors < page_lower_bound {lo} — page may read empty; review against the outline density curve")
        elif anchors > hi:
            rep.warn(f"{anchors} content anchors > page_upper_bound {hi} — page may be overloaded")

    return rep.dump("spec gate")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="mode", required=True)
    sp = sub.add_parser("spec", help="validate a slide-N.spec.json")
    sp.add_argument("spec")
    sp.add_argument("--style", required=True)
    st = sub.add_parser("style", help="validate a native style token file")
    st.add_argument("style")
    args = ap.parse_args()

    if args.mode == "style":
        sys.exit(validate_style(args.style))
    sys.exit(validate_spec(args.spec, args.style))


if __name__ == "__main__":
    main()
