<#
.SYNOPSIS
  ppt_export.ps1 — PowerPoint COM layer for the native ppt-agent pipeline (Windows only).
  Replaces LibreOffice/html2png/html2svg entirely.

.DESCRIPTION
  Modes:
    png    Export every slide of a .pptx to PNG (default 3840x2160) into -OutDir.
    pdf    Export the .pptx to PDF at -Out.
    check  Fidelity gate: the file must open cleanly (no repair) and contain >= 1 slide.
           Exit 0 = pass, exit 1 = fail.
    qa     Structural QA: text overflow (TextFrame2 bounds vs shape bounds) and
           off-slide shapes. Writes a JSON report to -Out; exit 1 if any FATAL finding.
    all    check + png + pdf in one PowerPoint session (delivery finishing).

  Serialization: PowerPoint's COM server is single-instance. All invocations of this
  script queue on a global mutex, so parallel PageAgents can call it concurrently and
  their exports run one at a time. Do NOT bypass the mutex by driving COM yourself.

.EXAMPLES
  powershell -ExecutionPolicy Bypass -File scripts\ppt_export.ps1 -Mode png   -InputFile out\slide-2.pptx -OutDir out\png
  powershell -ExecutionPolicy Bypass -File scripts\ppt_export.ps1 -Mode qa    -InputFile out\slide-2.pptx -Out out\qa-2.json
  powershell -ExecutionPolicy Bypass -File scripts\ppt_export.ps1 -Mode check -InputFile out\presentation.pptx
  powershell -ExecutionPolicy Bypass -File scripts\ppt_export.ps1 -Mode all   -InputFile out\presentation.pptx -OutDir out\png -Out out\presentation.pdf

.NOTES
  Requires desktop PowerPoint in an interactive user session (COM automation is not
  supported by Microsoft for unattended/headless servers). DisplayAlerts is disabled.
  The PowerPoint instance this script creates is always Quit() in finally; it never
  touches a PowerPoint window you had open yourself (it runs windowless).
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)] [ValidateSet('png', 'pdf', 'check', 'qa', 'all')] [string]$Mode,
  [Parameter(Mandatory = $true)] [string]$InputFile,
  [string]$OutDir,
  [string]$Out,
  [int]$Width = 3840,
  [int]$MutexTimeoutSec = 300
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2

$InputFile = (Resolve-Path -LiteralPath $InputFile).Path
$SLIDE_W_PT = 0.0   # filled after open
$SLIDE_H_PT = 0.0

function Fail([string]$msg) {
  Write-Error "ppt_export: $msg"
  exit 1
}

if (-not (Test-Path $InputFile)) { Fail "input not found: $InputFile" }
if ($Mode -in @('png', 'all') -and -not $OutDir) { Fail "-OutDir required for mode $Mode" }
if ($Mode -eq 'pdf' -and -not $Out) { Fail "-Out required for mode pdf" }
if ($Mode -eq 'qa' -and -not $Out) { Fail "-Out required for mode qa" }

# ---------- global queue: one COM export at a time ----------
$mutex = New-Object System.Threading.Mutex($false, 'Global\PptAgentNativeComExport')
$acquired = $false
try {
  try {
    $acquired = $mutex.WaitOne([TimeSpan]::FromSeconds($MutexTimeoutSec))
  } catch [System.Threading.AbandonedMutexException] {
    $acquired = $true  # previous holder died; mutex is ours
  }
  if (-not $acquired) { Fail "could not acquire COM queue mutex within ${MutexTimeoutSec}s — another export is stuck; check POWERPNT.EXE processes" }

  $pp = $null
  $pres = $null
  try {
    try {
      $pp = New-Object -ComObject PowerPoint.Application
    } catch {
      Fail "PowerPoint COM unavailable: $($_.Exception.Message). Desktop PowerPoint must be installed and this must run in an interactive session."
    }
    # ppAlertsNone = 1 — never block on dialogs
    try { $pp.DisplayAlerts = 1 } catch {}

    # Open: ReadOnly=msoTrue, Untitled=msoFalse, WithWindow=msoFalse
    try {
      $pres = $pp.Presentations.Open($InputFile, [Microsoft.Office.Core.MsoTriState]::msoTrue,
                                     [Microsoft.Office.Core.MsoTriState]::msoFalse,
                                     [Microsoft.Office.Core.MsoTriState]::msoFalse)
    } catch {
      # Interop types may be unavailable without PIA; retry with raw ints (-1 true, 0 false)
      try {
        $pres = $pp.Presentations.Open($InputFile, -1, 0, 0)
      } catch {
        Fail "FIDELITY FAIL: PowerPoint refused to open the file (likely corrupt OOXML): $($_.Exception.Message)"
      }
    }

    $slideCount = $pres.Slides.Count
    if ($slideCount -lt 1) { Fail "FIDELITY FAIL: file opened but contains 0 slides" }
    $SLIDE_W_PT = $pres.PageSetup.SlideWidth
    $SLIDE_H_PT = $pres.PageSetup.SlideHeight
    $height = [int][Math]::Round($Width * ($SLIDE_H_PT / $SLIDE_W_PT))

    if ($Mode -in @('check', 'all')) {
      Write-Output "CHECK OK: opened cleanly, $slideCount slide(s), ${SLIDE_W_PT}x${SLIDE_H_PT}pt"
    }

    if ($Mode -in @('png', 'all')) {
      New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
      $OutDirFull = (Resolve-Path -LiteralPath $OutDir).Path
      # slide-N numbering follows the deck order; zero-pad to keep sorts stable
      $pad = [Math]::Max(2, $slideCount.ToString().Length)
      foreach ($slide in $pres.Slides) {
        $n = $slide.SlideIndex.ToString().PadLeft($pad, '0')
        $png = Join-Path $OutDirFull "slide-$n.png"
        if (Test-Path $png) { Remove-Item $png -Force }  # stale renders must never survive a re-export
        $slide.Export($png, 'PNG', $Width, $height)
        Write-Output "PNG $png"
      }
    }

    if ($Mode -in @('pdf', 'all')) {
      $pdfPath = if ($Out) { $Out } else { [IO.Path]::ChangeExtension($InputFile, '.pdf') }
      $pdfDir = Split-Path -Parent ([IO.Path]::GetFullPath($pdfPath))
      if ($pdfDir) { New-Item -ItemType Directory -Force -Path $pdfDir | Out-Null }
      $pdfFull = [IO.Path]::GetFullPath($pdfPath)
      $pres.SaveAs($pdfFull, 32)  # ppSaveAsPDF = 32
      Write-Output "PDF $pdfFull"
    }

    if ($Mode -eq 'qa') {
      $findings = @()
      foreach ($slide in $pres.Slides) {
        foreach ($shape in $slide.Shapes) {
          $name = "$($shape.Name)"
          # off-slide check (1pt tolerance)
          if ($shape.Left -lt -1 -or $shape.Top -lt -1 -or
              ($shape.Left + $shape.Width) -gt ($SLIDE_W_PT + 1) -or
              ($shape.Top + $shape.Height) -gt ($SLIDE_H_PT + 1)) {
            $findings += [pscustomobject]@{
              severity = 'FATAL'; slide = $slide.SlideIndex; shape = $name; kind = 'off_slide'
              detail = "shape extends past the slide edge (L=$([Math]::Round($shape.Left,1)) T=$([Math]::Round($shape.Top,1)) W=$([Math]::Round($shape.Width,1)) H=$([Math]::Round($shape.Height,1)))"
            }
          }
          # text overflow check via TextFrame2 layout bounds
          $hasText = $false
          try { $hasText = ($shape.HasTextFrame -ne 0) -and ($shape.TextFrame2.HasText -ne 0) } catch {}
          if ($hasText) {
            $tf = $shape.TextFrame2
            try {
              $contentH = $tf.TextRange.BoundHeight + $tf.MarginTop + $tf.MarginBottom
              if ($contentH -gt ($shape.Height + 2)) {  # 2pt tolerance
                $findings += [pscustomobject]@{
                  severity = 'FATAL'; slide = $slide.SlideIndex; shape = $name; kind = 'text_overflow_v'
                  detail = "text needs $([Math]::Round($contentH,1))pt but the shape is $([Math]::Round($shape.Height,1))pt tall — shrink text, trim lines, or enlarge the frame in the spec"
                }
              }
              if ($tf.WordWrap -eq 0) {
                $contentW = $tf.TextRange.BoundWidth + $tf.MarginLeft + $tf.MarginRight
                if ($contentW -gt ($shape.Width + 2)) {
                  $findings += [pscustomobject]@{
                    severity = 'FATAL'; slide = $slide.SlideIndex; shape = $name; kind = 'text_overflow_h'
                    detail = "unwrapped text needs $([Math]::Round($contentW,1))pt but the shape is $([Math]::Round($shape.Width,1))pt wide"
                  }
                }
              }
            } catch {}
          }
        }
      }
      $report = [pscustomobject]@{
        file = $InputFile; slides = $slideCount
        fatal = @($findings | Where-Object { $_.severity -eq 'FATAL' }).Count
        findings = $findings
      }
      $qaDir = Split-Path -Parent ([IO.Path]::GetFullPath($Out))
      if ($qaDir) { New-Item -ItemType Directory -Force -Path $qaDir | Out-Null }
      $report | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 ([IO.Path]::GetFullPath($Out))
      Write-Output "QA $Out — $($report.fatal) fatal finding(s)"
      if ($report.fatal -gt 0) {
        $findings | ForEach-Object { Write-Output "  [$($_.severity)] slide $($_.slide) / $($_.shape): $($_.detail)" }
        exit 1
      }
    }
  }
  finally {
    if ($pres) { try { $pres.Close() } catch {} }
    if ($pp)   { try { $pp.Quit() }   catch {} }
    foreach ($o in @($pres, $pp)) {
      if ($o) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($o) }
    }
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
  }
}
finally {
  if ($acquired) { $mutex.ReleaseMutex() }
  $mutex.Dispose()
}
