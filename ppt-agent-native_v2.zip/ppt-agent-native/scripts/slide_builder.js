#!/usr/bin/env node
'use strict';
/**
 * slide_builder.js — build ONE single-slide .pptx from a slide spec, for the P4 QA loop.
 *
 * Usage:
 *   node scripts/slide_builder.js <slide-N.spec.json> --style <style.json> -o <slide-N.pptx>
 *
 * The output is a disposable QA artifact. The same render core produces the
 * final deck in deck_assembler.js, so what you QA is what ships.
 */

const fs = require('fs');
const path = require('path');
const core = require(path.join(__dirname, '..', 'lib', 'render_core.js'));

function fail(msg) {
  console.error(`slide_builder: ${msg}`);
  process.exit(1);
}

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--style') args.style = argv[++i];
    else if (argv[i] === '-o' || argv[i] === '--out') args.out = argv[++i];
    else args._.push(argv[i]);
  }
  return args;
}

const args = parseArgs(process.argv.slice(2));
const specPath = args._[0];
if (!specPath || !args.style || !args.out) {
  fail('usage: node slide_builder.js <spec.json> --style <style.json> -o <out.pptx>');
}

let spec, style;
try {
  spec = JSON.parse(fs.readFileSync(specPath, 'utf8'));
} catch (e) {
  fail(`cannot read spec ${specPath}: ${e.message}`);
}
try {
  style = JSON.parse(fs.readFileSync(args.style, 'utf8'));
} catch (e) {
  fail(`cannot read style ${args.style}: ${e.message}`);
}

const PptxGenJS = require('pptxgenjs');

(async () => {
  try {
    fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
    const pres = new PptxGenJS(); // one instance per output file — never reuse
    core.configurePresentation(pres, style);
    core.renderSlide(pres, spec, style, path.dirname(path.resolve(specPath)));
    await pres.writeFile({ fileName: args.out });
    console.log(`OK wrote ${args.out} (page ${spec.page}, type ${spec.page_type}, ${((spec.elements || []).length)} elements)`);
  } catch (e) {
    fail(e.message);
  }
})();
