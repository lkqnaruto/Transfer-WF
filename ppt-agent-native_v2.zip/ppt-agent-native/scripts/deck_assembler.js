#!/usr/bin/env node
'use strict';
/**
 * deck_assembler.js — assemble ALL approved slide specs into ONE native presentation.pptx
 * in a single PptxGenJS pass (consistent theme/fonts, no pptx merging).
 *
 * Usage:
 *   node scripts/deck_assembler.js <specs_dir> --style <style.json> -o <presentation.pptx>
 *   node scripts/deck_assembler.js <specs_dir> --style <style.json> -o out.pptx --preview <preview.html> --png-dir <png/>
 *
 * <specs_dir> must contain slide-N.spec.json files; slides are ordered by their
 * "page" field (not by filename). Every spec must already have passed
 * spec_validator.py — this script trusts its inputs but still fails loudly.
 *
 * --preview writes a static HTML grid of the COM-exported PNGs in --png-dir
 * (run ppt_export.ps1 first on Windows to produce them).
 */

const fs = require('fs');
const path = require('path');
const core = require(path.join(__dirname, '..', 'lib', 'render_core.js'));

function fail(msg) {
  console.error(`deck_assembler: ${msg}`);
  process.exit(1);
}

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--style') args.style = argv[++i];
    else if (argv[i] === '-o' || argv[i] === '--out') args.out = argv[++i];
    else if (argv[i] === '--preview') args.preview = argv[++i];
    else if (argv[i] === '--png-dir') args.pngDir = argv[++i];
    else args._.push(argv[i]);
  }
  return args;
}

const args = parseArgs(process.argv.slice(2));
const specsDir = args._[0];
if (!specsDir || !args.style || !args.out) {
  fail('usage: node deck_assembler.js <specs_dir> --style <style.json> -o <presentation.pptx> [--preview <preview.html> --png-dir <png/>]');
}

let style;
try {
  style = JSON.parse(fs.readFileSync(args.style, 'utf8'));
} catch (e) {
  fail(`cannot read style ${args.style}: ${e.message}`);
}

const specFiles = fs
  .readdirSync(specsDir)
  .filter((f) => /^slide-\d+\.spec\.json$/.test(f))
  .map((f) => path.join(specsDir, f));

if (!specFiles.length) fail(`no slide-N.spec.json files found in ${specsDir}`);

const specs = specFiles.map((f) => {
  try {
    const s = JSON.parse(fs.readFileSync(f, 'utf8'));
    if (typeof s.page !== 'number') throw new Error('missing numeric "page" field');
    return { file: f, spec: s };
  } catch (e) {
    return fail(`bad spec ${f}: ${e.message}`);
  }
});

specs.sort((a, b) => a.spec.page - b.spec.page);

// duplicate / gap check — a silently missing page is a delivery defect
const pages = specs.map((s) => s.spec.page);
for (let i = 1; i < pages.length; i++) {
  if (pages[i] === pages[i - 1]) fail(`duplicate page number ${pages[i]} (${specs[i - 1].file} and ${specs[i].file})`);
}
const expected = Array.from({ length: pages.length }, (_, i) => i + 1);
const gaps = expected.filter((p) => !pages.includes(p));
if (gaps.length) console.warn(`deck_assembler: WARNING missing page numbers: ${gaps.join(', ')} — assembling anyway, verify against outline.txt`);

const PptxGenJS = require('pptxgenjs');

(async () => {
  try {
    fs.mkdirSync(path.dirname(path.resolve(args.out)), { recursive: true });
    const pres = new PptxGenJS(); // fresh instance for this one output file
    core.configurePresentation(pres, style);
    for (const { file, spec } of specs) {
      try {
        core.renderSlide(pres, spec, style, path.dirname(path.resolve(file)));
      } catch (e) {
        fail(`${file}: ${e.message}`);
      }
    }
    await pres.writeFile({ fileName: args.out });
    console.log(`OK wrote ${args.out} (${specs.length} slides: pages ${pages.join(', ')})`);

    if (args.preview) {
      writePreview(args.preview, args.pngDir, specs);
    }
  } catch (e) {
    fail(e.message);
  }
})();

function writePreview(previewPath, pngDir, orderedSpecs) {
  let imgs = [];
  if (pngDir && fs.existsSync(pngDir)) {
    imgs = fs
      .readdirSync(pngDir)
      .filter((f) => /\.png$/i.test(f))
      .sort((a, b) => {
        const na = parseInt((a.match(/(\d+)/) || [0, 0])[1], 10);
        const nb = parseInt((b.match(/(\d+)/) || [0, 0])[1], 10);
        return na - nb;
      })
      .map((f) => path.relative(path.dirname(path.resolve(previewPath)), path.join(pngDir, f)).split(path.sep).join('/'));
  }
  const cells = imgs.length
    ? imgs.map((src, i) => `<figure><img src="${src}" alt="slide ${i + 1}" loading="lazy"><figcaption>${i + 1}</figcaption></figure>`).join('\n')
    : `<p>No PNGs found${pngDir ? ` in ${pngDir}` : ''}. Run ppt_export.ps1 on Windows, then re-run with --png-dir.</p>`;
  const titles = orderedSpecs.map((s) => `<li>${s.spec.page}. ${escapeHtml(s.spec.title || s.spec.page_type)}</li>`).join('\n');
  const html = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Deck preview</title>
<style>
body{font-family:Segoe UI,Calibri,sans-serif;margin:24px;background:#f4f4f4}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:16px}
figure{margin:0;background:#fff;padding:8px;border-radius:6px;box-shadow:0 1px 3px rgba(0,0,0,.15)}
img{width:100%;display:block;border-radius:2px}
figcaption{text-align:center;color:#666;font-size:12px;padding-top:6px}
ol,ul{columns:2}
</style></head><body>
<h1>Deck preview (${orderedSpecs.length} slides)</h1>
<ul>${titles}</ul>
<div class="grid">
${cells}
</div></body></html>`;
  fs.writeFileSync(previewPath, html);
  console.log(`OK wrote ${previewPath} (${imgs.length} thumbnails)`);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}
