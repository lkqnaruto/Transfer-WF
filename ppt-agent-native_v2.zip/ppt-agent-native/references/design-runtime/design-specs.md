# 设计规格书（A/B/C/D/E -- native 版，由 `scripts/resource_loader.py` 自动注入 GLOBAL_RESOURCES）

> 画布规范、排版阶梯、卡片规则、色彩装饰、页面类型与输出规范的原生（PptxGenJS）版本。
> 渲染由受信 `slide_builder.js` 完成；本规格书约束的是 spec 的坐标与取值。

---

## A. 画布与排版

### 画布规范（不可修改）

- 固定尺寸：**13.333 × 7.5 英寸**（LAYOUT_WIDE，= 960×540pt）；frame 单位英寸，2 位小数
- 出画布 = 直接隐形（pptxgenjs 不裁剪）；spec_validator 硬拦截
- 内容安全区：x 0.5–12.83，y 0.35–7.1；content 页正文区 y ≥ 1.6（标题区由 builder 自动渲染）
- shape/image 允许贴边出血；文字类元素不允许

### 排版阶梯（pt）

| 层级 | 字号 | 用法 |
|---|---|---|
| 封面主标题 | 40–48 | cover/end，builder 自动 |
| 页标题 | 24–28 | content，builder 自动 |
| 章节标题 | 36–44 | section，builder 自动 |
| KPI 大数字 | 44–72 | kpi.value_size |
| 卡片标题 | 14–16 | card.title_size |
| 正文/列表 | ≥ min_body_font_pt（常 11–14） | text/bullets/card body |
| Caption | 8–10 | `"role":"caption"` 专用 |

字号差距要拉开：页内最大与正文字号至少 2.5 倍差，避免"公文盒子感"。

## B. 卡片规则

- 每页 ≥2 种 card_style 混用；accent ≤1、elevated ≤1（聚光灯唯一性）
- card body 行数 ≤ `max_lines_per_card`；每行是短语不是长句
- anchor 卡获得最大 frame 或唯一 accent/elevated 处理；support 卡用 filled/outline/tint 退后
- 同排卡片等高；间距统一取 0.25–0.4in 中的一个值，不得随机混用

## C. 色彩与装饰

- 一切颜色写 token 名；accent_1 唯一主强调；数据对比用 chart_palette 顺序
- 装饰 shape 总数 ≤ `decoration_budget`；武器选型见 `css-weapons.md`（W1–W8 原生武器）
- signature_move 每 3–4 页至少出现一次；相邻页装饰组合不得同构
- 深底风格文字对比度 ≥4.5:1；禁止 grid 色文字压 bg_secondary 底这类低对比组合

## D. 页面类型要点

| page_type | builder 自动渲染 | spec 要做的 |
|---|---|---|
| cover | 居中大标题+副标题 | 1–2 个装饰元素 + caption（日期/机构），大量留白 |
| toc | 左上页标题 | 编号卡片列表（filled/outline 交替）或 bullets |
| section | 左侧大标题 | W4 水印序号 + 1 个装饰武器，其余留白 |
| content | 左上页标题+副标题 | 全部内容元素，y≥1.6 起排 |
| end | 居中大标题 | 同 cover，可放联系方式 caption |

## E. 输出规范

- spec 文件 = 纯 JSON，无注释、无思考过程、无旁白文案
- 先过 `spec_validator.py spec` Gate 再进入构建
- 构建产物（.pptx/.png）一次性，不得手改；一切修复回到 spec
