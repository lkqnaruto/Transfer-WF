# 原生装饰武器库（W1-W8，native 版）

> 由 `scripts/resource_loader.py` 根据每页 `decoration_hints`（含 W 编号）按需注入。
> 每件武器都是 **spec 元素组合**（shape/text/kpi），不是 CSS。相邻页的武器组合应该不同。
> 策划阶段在 `decoration_hints` 中用 W 编号引用：如 `W1 标题短横条 | accent_1`。
> 所有 shape 计入 `density_contract.decoration_budget`——先数预算再选武器。

---

## W1. 标题短横条（signature 级，最便宜）

```json
{ "type": "shape", "shape": "rect", "frame": {"x":0.5,"y":1.18,"w":1.1,"h":0.06}, "fill": "accent_1" }
```
放在自动标题区正下方。成本 1 shape。

## W2. L 形角标（控制台感 / 精密感）

```json
{ "type": "shape", "shape": "line", "frame": {"x":0.5,"y":1.7,"w":0.5,"h":0},  "line": {"color":"accent_1","width":1.5} }
{ "type": "shape", "shape": "line", "frame": {"x":0.5,"y":1.7,"w":0,"h":0.5},  "line": {"color":"accent_1","width":1.5} }
```
页面或核心卡片的对角各放一组（成本 2 shape/组）。深底风格首选。

## W3. 全高侧色带（章节页/封面分区）

```json
{ "type": "shape", "shape": "rect", "frame": {"x":0,"y":0,"w":0.18,"h":7.5}, "fill": "accent_1" }
```
仅限 cover/section/end 页（content 页禁用——会和满幅页眉条一样变成噪音）。成本 1 shape。

## W4. 大号水印数字/字母（章节序号）

```json
{ "type": "text", "frame": {"x":8.5,"y":2.2,"w":4.3,"h":3.6}, "text": "02",
  "size": 200, "bold": true, "color": "grid", "align": "right" }
```
用最浅的 token（grid / bg_secondary）模拟半透明水印。放在留白侧，不得压正文。成本 0 shape（text 不占装饰预算，但一页最多 1 个水印）。

## W5. 细分隔线

```json
{ "type": "shape", "shape": "line", "frame": {"x":0.5,"y":4.1,"w":12.33,"h":0}, "line": {"color":"grid","width":0.5} }
```
分隔上下两个内容区。成本 1 shape。

## W6. 底部收束条（仅深底风格）

```json
{ "type": "shape", "shape": "rect", "frame": {"x":0,"y":7.26,"w":13.333,"h":0.24}, "fill": "bg_secondary" }
```
封面/结尾页的底部镇纸。content 页禁用。成本 1 shape。

## W7. 数据强调点（oval 圆点标记）

```json
{ "type": "shape", "shape": "oval", "frame": {"x":7.5,"y":1.78,"w":0.14,"h":0.14}, "fill": "accent_3" }
```
放在 KPI 或结论行左侧作视觉引导点。成本 1 shape/个，最多 3 个。

## W8. 双细线夹注（报告感）

```json
{ "type": "shape", "shape": "line", "frame": {"x":0.5,"y":6.72,"w":12.33,"h":0}, "line": {"color":"grid","width":0.5} }
{ "type": "shape", "shape": "line", "frame": {"x":0.5,"y":6.76,"w":12.33,"h":0}, "line": {"color":"grid","width":0.5} }
```
页脚 caption 行上方的双细线。成本 2 shape。

---

## 已阵亡武器（禁止尝试复刻）

渐变文字、毛玻璃、glow 光晕、网格点阵底纹、clip-path 斜切、CSS 动画、旋转文字。
需要类似氛围时按 `styles/README.md` 降级对照表选原生等价物。
