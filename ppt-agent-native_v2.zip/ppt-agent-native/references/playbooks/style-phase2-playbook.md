# Style Phase 2 Playbook -- JSON 风格合同质量自审

## 目标

在 Phase 1 输出 `style.json` 之后，立即切换为风格质检员视角（QA）。对刚刚这份长篇大论的 JSON 配置进行严格的合法性、逻辑性和结构化对账。

---

## 自审动作流程

1. **直接验证原文件**：逐项检查 `style.json`，如果发现任何不合格项，原地直接用工具改写该 JSON 返回值，不要新建文件。
2. **多轮重审**：修改完成后，重新通读一遍 7 项清单，最多允许 2 轮自我修补循环。

---

## 合法性边界（The 7-item Checklist）

你在发送最终 FINALIZE 信号前，必须在脑海或推演日志中逐一核实以下 7 项标准：

| # | 核查重点 | 容错界限与处理方式 |
|---|--------|------------------|
| 1 | `design_soul` 的高度 | 不能写成：带圆角的蓝色渐变大方块。必须是：体现科技企业理性的扁平化现代商务风，克制使用色彩。它描述的是这套 PPT 的**设计灵魂和意图**。不到位则重写。 |
| 2 | `variation_strategy` 的维度 | 不能是一套逐页执行脚本。它必须明确说明：“哪些基础元素要全局贯穿（如品牌基色、圆角）”和“哪些部分允许页面级灵动发挥（如卡片底色的交错搭配）”。缺失任何一极则打回重构。 |
| 3 | `decoration_dna.forbidden` 的有效性 | 写在这里的内容必须真的能够**阻止风格的无序漂移**。如：“禁止使用红绿高烈度撞色”、“禁止把卡片阴影参数设得太大产生脏污”。若只是一句空话（禁止不好看的乱画），必须重写。 |
| 4 | `recommended_combos` 的语法性 | 这到底是一套“组合语法”还是干巴巴的命令？它的内容应当像药方：“当一页很长时，推荐 `elevated` 底色搭配 `text-primary` 副标题”，而不是“第一页你要加粗副标题”。若写成单页指令，必须抽象为通用法则。 |
| 5 | `colors` 的基石稳定 | 必须逐字核对 12 个强制 token 名（bg_primary/bg_secondary/card_bg/card_border/text_primary/text_secondary/accent_1..4/on_accent/grid），全部为 6 位无 # hex。漏掉任何一个校验必崩。如果漏了，立刻回写补齐。 |
| 6 | `card_recipes` 与 `chart_palette` 完备 | `card_recipes` 必须包含 filled/outline/accent/elevated/tint 五个对象且引用的 token 全部存在；`chart_palette` 是 3-4 个 token 名的数组且首位 accent_1。accent 配方的文字色必须是 on_accent。 |
| 7 | 数组长度红线（致命关键） | 严格清点三个数组的长度：`mood_keywords` **必须是 3-5 个**；`decoration_dna.forbidden` **必须是 2-5 个**；`recommended_combos` **必须是 2-4 个**。少一个多一个都会触发脚本严重报错并直接阻断流程！若发现不合规请立即原地增删。 |

---

## FINALIZE 签名契约

只有在 7 项检查全部自审并修补通过后，你才可以发出信号终结该流程：

```
FINALIZE: 自审通过
- style: [STYLE_OUTPUT 路径]
- 自审轮数: N
- 修复发现: [列举你按照要求修复了什么不规范字段，若无填 无]
```
