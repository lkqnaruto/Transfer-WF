# Page Spec Playbook -- 单页原生 Spec 设计稿

## 目标

忠实还原 planning JSON 里的骨架与精神，将抽象组件落地为**一份声明式 `slide-N.spec.json`**。
你不写任何渲染代码：`slide_builder.js` 是唯一渲染器，spec 是它唯一的输入，也是后续 QA 唯一的修改面。

---

## Phase 1：骨架理解（不得跳过）

读取 `planning{n}.json` 的以下字段作为本阶段的硬约束：

| 字段 | Spec 阶段的含义 |
|------|--------------|
| `page_type` / `layout_hint` | 决定 spec 的 `page_type` 与元素坐标骨架（见 layouts/ 对应文件的英寸网格） |
| `density_label` / `density_contract` | 逐字段复制进 spec 的 `density_contract` -- spec_validator 会逐条执法 |
| `focus_zone` | 决定哪个元素获得最大 frame 与视觉权重 |
| `negative_space_target` | 决定留白：high=大 frame 间距 / low=紧凑网格 |
| `cards[].role` / `cards[].card_style` | anchor 卡用 accent/elevated（各页最多 1 个），support 用 filled/outline/tint |
| `cards[].card_id` | 落到 spec 元素的 `id` 字段，Review 阶段逐一对账 |
| `cards[].content_budget` | 卡片 body 行数上限，防止溢出 |
| `cards[].chart.chart_type` | 映射到原生 chart_type（见 charts/ 对应文件）；无原生形式的必须按 charts 文件降级方案处理，不得偷换语义 |
| `director_command` / `decoration_hints` | 用 shape 元素表达，总数受 `decoration_budget` 约束 |
| `source_guidance` / `must_avoid` | 来源说明放 `role: "caption"` 的 text 元素；must_avoid 是硬边界 |
| `image.mode` | 严格按 Phase 3 执行 |

---

## Phase 2：坐标物理红线（不可违反）

画布 = **13.333 × 7.5 英寸**（LAYOUT_WIDE），所有 frame 单位是英寸，保留 2 位小数。

- **越界即隐形**：pptxgenjs 不裁剪坐标，出画布的元素直接消失。spec_validator 会拦截，但你应当一次写对。
- 内容元素（text/bullets/card/kpi/chart/table）与画布边缘至少留 **0.4in**；shape 装饰允许贴边/出血。
- 标题区由 builder 按 `page_type` 自动渲染（content 页标题占 y=0.35–1.5），**内容元素从 y≥1.6 开始**；cover/section/end 的标题也由 builder 接管，spec 里只放装饰与补充元素。
- 相邻卡片之间留 0.25–0.4in 间距；同排卡片先算总宽：`n×w + (n-1)×gap ≤ 12.53`。
- 字号单位是 pt：正文不得低于 `density_contract.min_body_font_pt`；来源/日期等辅助行标 `"role": "caption"`（下限 8pt）。
- 每页 accent 卡 ≤1、elevated 卡 ≤1；shape 装饰总数 ≤ `decoration_budget`。

## Phase 3：图片模式严格执行

| image.mode | spec 要做什么 |
|-----------|-------------|
| `generate` / `provided` | `{"type":"image","path":"<source_hint>"}`，路径必须真实存在 |
| `manual_slot` | 用 outline 卡片渲染占位框，title 写「[图片替换位]」+ 尺寸说明 |
| `decorate` | 不用外部图片；用 shape 元素（色块、细线、L 形角标）+ KPI 大数字补足视觉氛围 |

`density_contract.image_policy = "none"` 时 spec 中不得出现任何 image 元素（validator 硬拦截）。

---

## Phase 4：卡片落地对账（强制）

- `planning.cards[]` 中的每一张卡都必须有一个对应的 spec 元素，`id` = `card_id`。
- `role = anchor` 的卡必须是全页第一视觉落点（最大 frame / accent 或 elevated / KPI 锚点）。
- 带 `chart.chart_type` 的卡，spec 里的 chart_type 必须语义一致；不得把 comparison_bar 偷换成文字列表。
- 装饰 shape 不承载信息，条数计入 `decoration_budget`。
- **【反泄漏清扫防线】**：planning 的 `body`/`headline` 里若混入「旁白解说」「排版动作」（如"这一页先铺垫再收束"），**不得原样写进 spec 文案**——剔除或改写为干货。

---

## Phase 5：风格绑定

spec 里所有颜色**只写 token 名**（bg_primary / card_bg / text_primary / text_secondary / accent_1..4 / on_accent / grid），不写裸 hex——全局换肤只应该发生在 style.json。

- `design_soul`：校准文案与布局情绪，不得抄成页面文字
- `variation_strategy`：控制本页与相邻页的差异（卡片风格组合、装饰组合不得与相邻页同构）
- `decoration_dna.signature_move`：跨页识别锚点，每 3–4 页至少出现一次（用 shape 元素实现）
- `decoration_dna.forbidden`：硬边界，违反即不达标

---

## Phase 6：完成条件

写入目标 spec 文件后：

- JSON 语法合法、非空
- 本地先跑 Gate：`spec_validator.py spec <spec> --style <style.json>` 退出码 0
- `planning.cards[]` 全部能在 spec 中找到对应 `id`
- 文件绝对纯净：不得包含思考过程、自检说明等与页面无关的字段或文案

发送阶段完成信号，等待 Build & Review 阶段指令。
