# Page Build, QA & Visual Review Playbook -- 单页图审与 Spec 修复（native 版）

## 目标

构建并导出真实 PowerPoint 渲染的 PNG 后，切换为**像素级严苛的演示设计总监**身份，按结构化扫描协议逐区检查 PNG，发现问题立刻定位到 spec 元素并修复，直到页面达到可交付标准。

**核心原则：看图说话，改 spec 验证。不猜、不假设、不口头放行。唯一修改面是 `slide-N.spec.json`。**

---

## Part A-0：构建 + 导出 + 存档协议（每轮强制执行，不得跳过）

> **为什么需要这个**：LLM 极易产生"我已经修好了"的幻觉。物理重建 + 前后对比是唯一可靠的验证手段。

### 每轮固定四步（路径取自任务包）

```bash
# A-0-1：spec -> 单页原生 pptx（构建报错 = spec 有误，按报错信息修 spec）
node SKILL_DIR/scripts/slide_builder.js SPEC_OUTPUT --style STYLE_PATH -o SLIDE_PPTX_OUTPUT

# A-0-2：PowerPoint COM 导出 PNG（真实渲染；全局队列自动串行）
powershell -ExecutionPolicy Bypass -File SKILL_DIR/scripts/ppt_export.ps1 -Mode png -InputFile SLIDE_PPTX_OUTPUT -OutDir PNG_DIR

# A-0-3：COM 结构 QA（文字溢出 TextFrame2 实测 + 出画布检查）
powershell -ExecutionPolicy Bypass -File SKILL_DIR/scripts/ppt_export.ps1 -Mode qa -InputFile SLIDE_PPTX_OUTPUT -Out COM_QA_REPORT_PATH

# A-0-4：归档到轮次目录（X = 当前轮次编号）
mkdir REVIEW_DIR/roundX
cp PNG_OUTPUT REVIEW_DIR/roundX/slide-N.png
```

### 验证规则（第 2 轮起强制执行）

从第 2 轮开始，只查看**本轮的最新截图**：
1. **不要再读取上一轮的图片**，只用当前宿主可用的图像查看能力查看 `REVIEW_DIR/roundX/slide-N.png`。
2. **逐条对照**上轮报告中所有 `[发现]` 项，在**新截图中确认**每项是否真正修复。
3. 如果发觉自己确实改了 spec，但新截图效果却无变化，检查是否忘了重新执行 A-0-1/A-0-2（构建产物不会自己更新）。

**禁止行为**：
- 禁止不重建/不导出就声称修复通过
- 禁止基于 spec 修改推理截图应该是什么样（必须实际观察最新截图像素）
- 禁止手改 .pptx / .png——它们下一轮就会被覆盖

---

## Part A：视觉扫描协议（每轮导出后必须执行）

先读 `COM_QA_REPORT_PATH`：每条 FATAL（text_overflow_v / text_overflow_h / off_slide）都带 slide/shape/差值，
直接映射回 spec 元素（shape 名对应元素顺序与内容），这是最高优先修复清单。

然后对照 `planning` 中的 `density_contract` 做 4 项合同核对：
- 当前页的卡片数、图表数是否超预算
- 正文是否明显小于 `min_body_font_pt`
- `image_policy` 是否被 spec 偷偷突破
- `decoration_budget` 是否被过量 shape 突破

### 第 1 遍：边界巡逻（由外向内）

| 扫描区 | 看什么 | 典型问题 |
|--------|--------|---------|
| **四角** | 内容是否被截断？角落是否有意外空白或残留元素？ | frame 越界（不可见）、装饰错位 |
| **四边** | 文字/色块是否紧贴 13.333×7.5in 边框（边距 < 0.3in）？ | 边距不足、caption 贴底 |
| **底部 caption 区** | 来源行是否存在？是否与内容重叠？ | 内容区超高压住 caption |

### 第 2 遍：内容区纵深扫描（从主到次）

| 扫描区 | 看什么 | 典型问题 |
|--------|--------|---------|
| **标题区（builder 自动渲染）** | 标题是否完整清晰？副标题是否换行异常？ | 标题过长换行、与内容区重叠（内容未从 y≥1.6 起排） |
| **焦点区（focus_zone 指定位置）** | 是否是全页视觉第一落点？尺寸/色彩优势是否足够？ | anchor 卡视觉权重不够 |
| **支撑区（焦点以外的卡片）** | 内容完整可读？卡片间距均匀？是否互相重叠？ | frame 重叠、gap 不均、body 被压缩 |
| **图表区** | 轴字是否可读？数据标签是否重叠？图例是否被裁？ | chart frame 过小、类目过多 |
| **装饰层** | shape 装饰是否压住文字？是否抢焦点？ | 装饰 frame 与文字 frame 相交 |

### 第 3 遍：整体印象（退后一步看）

| 检查项 | 判断标准 |
|--------|---------|
| **一秒焦点测试** | 闭眼再看，第一个注意到的是不是本页最重要的信息？ |
| **毛坯房测试** | 看起来像精心设计的演示文稿，还是像默认模板？ |
| **风格一致性** | 色彩、装饰是否符合 `design_soul` 描述的情绪？ |
| **与相邻页区分度** | 布局/卡片组合是否与前一页明显不同？ |

---

## Part B：严重度分级（决定修复优先级）

发现问题后，按严重度分类。**P0 不通过则整页不通过，必须先修 P0 再处理 P1/P2。**

### P0 — 致命缺陷（任一存在 → 本轮不通过）

| ID | 症状 | 根因诊断 | Spec 修复配方 |
|----|------|---------|-------------|
| P0-1 | COM QA 报 text_overflow（文字超出 shape） | body 行数过多 / 字号过大 / frame 过小 | 按报告差值：加高 frame、删减 body 行、或降字号（不得低于 min_body_font_pt；再放不下 → 减内容或回退 planning） |
| P0-2 | COM QA 报 off_slide（元素出画布） | frame 坐标算错 | 按报告坐标修 frame，重算同排总宽 |
| P0-3 | 大面积空白（超过画布 40% 无内容无装饰） | planning 卡片未落地 | 对照 planningN.json 的 cards 逐一检查，补回缺失元素 |
| P0-4 | 核心文字不可读（低对比、字号过小） | 颜色 token 用错（深底浅字/浅底深字颠倒） | 换正确 token（深底页文字用 text_primary=浅色系）；正文 ≥ min_body_font_pt |
| P0-5 | planning 中的关键卡片在 PNG 中完全缺失 | spec 漏元素或 frame 越界隐形 | 对照 planning cards[] 补回缺失元素，核对 frame 在画布内 |
| P0-6 | 元素互相重叠（文字压文字、卡片压卡片） | frame 区间相交 | 重算坐标：同排卡片 `n×w+(n-1)×gap ≤ 12.53`；上下块 y 区间不相交 |
| P0-7 | 构建失败（slide_builder 报错） | spec 语法/枚举/数据不合法 | 按报错信息修 spec，再过 spec_validator |
| P0-8 | 图片破损或严重变形 | path 错误 / sizing 缺失 | 核对 IMAGES_DIR 真实路径；补 `"sizing": "cover"` |

### P1 — 必修缺陷（不影响基本可用，但显著降低品质）

| ID | 症状 | Spec 修复配方 |
|----|------|-------------|
| P1-1 | 文字接近溢出（贴边、局促） | frame 加高 0.2-0.3in 或删一行 body |
| P1-2 | 卡片间距不均 | 统一 gap 为 0.25-0.4 中的一个值，重算 x/y |
| P1-3 | 装饰 shape 遮挡文字 | 移动装饰 frame 到留白区，或删除（装饰永远让位内容） |
| P1-4 | 无视觉焦点（所有卡片同质） | anchor 卡换 accent 或 elevated（各 ≤1/页）；加 kpi 锚点 |
| P1-5 | spec 里出现裸 hex 而非 token | 全部替换为 colors token 名 |
| P1-7 | 关键数字与正文同字号 | 改用 kpi 元素或 runs 加粗 + accent_1 色 + 更大字号 |
| P1-8 | 卡片 body 行数贴上限、读感拥挤 | 精简为短语；行数留出 1 行余量 |
| P1-9 | **设计独立性缺失**（连续 3+ 页同构布局） | 按本页 page_goal 重选 layout 网格与 card_style 组合，不沿用上一页结构 |

### P2 — 抛光项（品质提升，非阻塞但鼓励修复）

| ID | 症状 | 修复建议 |
|----|------|---------|
| P2-1 | 同排卡片高度不一 | 统一 h |
| P2-2 | 缺少 `signature_move` 装饰 | 按 decoration_dna 补对应 shape（预算内） |
| P2-3 | badge 编号断序或缺失 | 补齐 badge |
| P2-4 | 页面平淡缺层次 | 唯一 elevated 卡制造浮起感；tint 底分组 |
| P2-5 | 标题与正文字号梯度不足 | 拉开至 ≥2.5 倍差（KPI/标题档提上去） |
| P2-6 | caption 缺失来源 | 按 source_guidance 补 role:caption 行 |

---

## Part C：结构化审查报告模板（每轮必须输出）

每轮审查后，严格按以下格式输出（不得省略任何级别）：

```
## 审查报告 — 第 N 页 / 第 X 轮

### COM QA
- fatal 数: N（逐条列出 slide/shape/kind/差值 → 对应 spec 修复动作）

### P0 致命缺陷
- [P0-1..P0-8] 逐条 [发现/通过]，发现则附修复动作

### P1 必修缺陷
- [P1-1..P1-9] 逐条 [发现/通过]

### P2 抛光项
- [P2-1~P2-6] 逐条简述

### 本轮判定
- P0 全部通过: 是/否
- 修复动作数: N
- 同类未收敛问题: [如有，列出问题 ID]
- 是否触发回退 planning: 是/否
- 进入下一轮: 是（仍有修复需验证）/ 否（达标，准备 FINALIZE）
```

**输出报告后立即执行修复**——不是写完报告等指令，而是边报告边改 spec。

---

## Part D：修复执行规范

### 修复顺序（铁律）

```
P0（致命）→ P1（必修）→ P2（抛光）
```

**同级内部的优先级**：
1. 内容缺失/溢出 → 先补/裁内容
2. 坐标/重叠 → 再修 frame
3. 对比度/可读性 → 然后修 token 用色
4. 装饰/质感 → 最后打磨

### 修复力度：大刀阔斧，不要畏手畏脚（Aggressive Repair）

当发现严重溢出、重叠、密度爆炸时，**不要试探性地挪 0.05in "微调"**：
- **重算整排**：一排卡片有一张溢出，通常整排预算错了——重算 `n×w+(n-1)×gap`，全排一起改。
- **砍内容保可读**：body 放不下就删行、短语化，不许把字号压到 min_body_font_pt 以下硬塞。
- **斩装饰保内容**：装饰与内容抢空间时，直接删装饰。"简单干净但清晰可读"永远完爆"花哨却糊成一团"。
- **改完必过 Gate**：每次修改后先跑 `spec_validator.py spec`，Gate 报错按 FIX 提示改，再进入重建。

### 修复后的验证规则

每次修改 spec 后：
1. **必须重新执行 A-0 全套四步**（构建 → 导出 → QA → 存档），不得凭想象判断修复效果
2. 重新执行 Part A 扫描协议（至少快速过一遍边界巡逻 + COM QA 报告）
3. 对照上轮报告中的 `[发现]` 项，确认是否变为 `[通过]`
4. 注意修复是否引入了新问题（挪 frame 挤到邻居的情况很常见）

---

## Part E：轮次控制（无上限，直到完美）

> **铁律：最少 2 轮，第 1 轮禁止 FINALIZE，且不设上限次数。** 若某轮修复后仍有缺陷，**必须无条件进入下一轮**，绝对不允许妥协或带病交付！

| 轮次 | 重点 | 本轮目标 | 能否 FINALIZE |
|------|------|---------|-------------|
| **第 1 轮** | 全量扫描（Part A 完整 3 遍）+ 大刀阔斧修复所有 P0 和 P1 | P0, P1 全部修完 | **否**（必须进入第 2 轮验证） |
| **第 2 轮及之后** | 验证修复落地（看新图 + 新 QA 报告） | P0+P1 绝对清零 + COM QA 退出码 0 + spec Gate 通过 | 是（仅当完全无缺陷时） |

**FINALIZE 必要条件**（缺一不可）：
- **P0 全部清零**、**P1 全部清零**
- **COM QA 退出码 0**（任何 FATAL → 禁止 FINALIZE）
- **spec_validator 退出码 0**
- **至少完成 2 轮审查**

### 回退止损规则（硬门）

- 如果同一个 P0 / P1 类别在连续 2 轮的新截图里仍然存在，说明问题不是坐标微调能解决，而是 planning 骨架或预算本身有问题。
- 此时**停止继续修 spec**，在报告中明确写出 `是否触发回退 planning: 是`，并说明需要重开的原因（预算超载 / 布局承重墙错误 / 高密页塞不下 / dashboard 不适合当前内容）。
- 回退后必须重写 `density_label / density_contract / layout_hint / cards 分配` 中至少一项，禁止只挪 0.1in 边距再回来。

---

## Part F：内容合同违约检查（对照 Runtime Failure Modes）

在 Part A 扫描的第 2 遍中，同步检查以下内容合同：

| Failure Mode | PNG 中的视觉信号 | 修复方向 |
|-------------|-----------------|---------|
| **underfill** | 页面大量留白 + 装饰多于文字 | 先补 payload（回到 planning 检查缺失内容） |
| **support collapse** | 只有一个大数字/大标题，无解释层 | 补充支撑卡片的 body 内容 |
| **payload missing** | 某个 planning card 在页面上找不到 | 补回缺失的 spec 元素 |
| **source overclaim** | 结论性文字很强但无数据/引用支撑 | 检查 brief 中是否有依据，无则弱化措辞 |
| **anchor overexpansion** | 一个元素占据 >60% 画面，其余挤在角落 | 缩小锚点 frame 至 40-50%，释放空间给支撑层 |
| **decorative substitution** | 装饰 shape 多而信息密度低 | 删装饰，补实质内容 |

**修复顺序**：先补内容 → 再调结构 → 最后修装饰。不允许用装饰调整掩盖内容缺失。

---

## 闭环承诺

- 每轮：**构建+导出+QA+存档 → 读 QA 报告 → 看最新截图 → 3 遍扫描 → 结构化报告 → 立即改 spec → 重建验证**
- 任何"我认为应该没问题"都不算，必须用新 PNG + QA 报告验证
- **禁止幻觉放行**："改了 spec 所以应该好了"不算通过，必须重建后确认
- P0 是铁律，P1 是底线，P2 是追求；P0/P1 有残留就无限循环修复，直到根除
- 最终轮必须 COM QA 退出码 0 且 spec Gate 通过
