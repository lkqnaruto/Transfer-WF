# primary-secondary -- 主次栏

> 主区放核心证据（chart/table），次区放解读（kpi/卡片）。数据页的默认骨架。

## 网格

- 主区：x 0.5 y 1.7 w 7.4 h 4.9（chart 建议 h 4.4，下留 caption）
- 次区：x 8.3 y 1.7 w 4.53 h 4.9，纵向切 2–3 块：
  - kpi 行：y 1.7 h 1.5（可并排 2 个 kpi，各 w 2.2）
  - 卡片 1：y 3.4 h 1.3–2.2
  - 卡片 2：y 4.85 h 1.25–1.6
- caption 行：x 0.5 y 6.9

## 规则

- 主区是 anchor；次区卡片 ≤2 张，其一可用 accent（全页唯一燃点）
- 次区文案是"so what"解读，不复述主区数字
