# three-column -- 三分栏

> 三个并列要点/方案/阶段。中高密度的标准解法。

## 网格

- 三栏：w 4.0，x = 0.5 / 4.67 / 8.83，y 1.7，h 4.6
- 每栏 = 1 张 card（badge 1/2/3）或 kpi + card 纵向组合（kpi h 1.4 在 y 1.7，card 在 y 3.3 h 3.0）
- caption 行：y 6.9

## 规则

- 三栏等宽等高；badge 编号连续；body 行数一致（差 1 行以内）
- 三栏 card_style 可做 filled/outline/filled 交替，但中栏若是推荐项才可用 accent（全页唯一）
