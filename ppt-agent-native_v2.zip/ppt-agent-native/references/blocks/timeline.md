# timeline -- 时间线/里程碑

> 水平主轴 + 节点 + 节点卡。用 shape 骨架 + card 组合原生实现。

## 配方（4 节点版）

```json
{ "type": "shape", "shape": "line", "frame": {"x":0.9,"y":4.0,"w":11.5,"h":0}, "line": {"color":"grid","width":1.5} }
{ "type": "shape", "shape": "oval", "frame": {"x":1.83,"y":3.89,"w":0.22,"h":0.22}, "fill": "accent_1" }
```
- 节点 oval x 中心 = 2.0 / 5.1 / 8.2 / 11.3（0.22 见方，y 3.89 压轴线）
- 节点卡上下交错：上卡 y 2.2 h 1.4，下卡 y 4.5 h 1.4，w 2.6，x = 节点中心 − 1.3
- 卡 title = 时间点（bold），body = 1–2 行事件短语
- 当前/关键节点：oval 放大到 0.3 + 该卡用 accent（全页唯一）

## 规则

- 3–5 节点为宜；节点数 >5 改用 table（列=阶段）
- 轴线和节点 oval 计入 decoration_budget 吗？——不计（它们是信息骨架不是装饰），但 spec_validator 按 shape 统计，故 planning 给 timeline 页的 decoration_budget 至少 = 节点数 + 2
