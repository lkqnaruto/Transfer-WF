# image-hero -- 主视觉图

> 大图主导的页面。严格受 `density_contract.image_policy` 管制，无图时走 decorate 降级。

## 配方 A：半幅大图（image_policy 允许 + 图片存在）

- image：x 6.83 y 0 w 6.5 h 7.5（右半出血，sizing "cover"）
- 左半：标题区之下放 quote/kpi/短 bullets，x 0.5 w 5.9
- 深色图上不压字；文字全部留在无图半区

## 配方 B：manual_slot 占位

outline 卡 w 6.5 h 4.5 居右，title "[图片替换位 16:9]"，body 1 行说明想要的画面。

## 配方 C：decorate 降级（无图）

放弃图位，改 single-focus/quote 骨架 + W3 侧色带 + W4 水印制造画面感。

## 规则

- hero 图只出现在 low/mid_low 密度页；high/dashboard 页禁止（同 HTML 时代红线）
- 图片必须真实存在于 IMAGES_DIR，路径进 spec 前先核对 image 清单快照
