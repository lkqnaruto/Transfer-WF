# people -- 人物/团队

> 人物网格：头像位 + 姓名 + 头衔。无照片时用姓氏首字圆徽降级，不放占位图。

## 配方（1 人单元，横向排 3–4 个）

- 单元 card（filled）：w 2.9 h 2.2（三人版 x = 0.5 / 4.67 / 8.83，y 2.2）
- 有照片（image_policy 允许）：image 元素 w 0.9 h 0.9 圆内裁切不可用，方图即可，放单元卡上部居中
- 无照片：oval shape（w 0.7 h 0.7，fill accent_1）+ 首字 text（on_accent，bold，居中叠放）
- 姓名 text（bold 14pt）+ 头衔 caption（10pt）+ 一行亮点 body

## 规则

- ≤4 人/页；人越少单元越大；核心人物单元可用 elevated（全页唯一）
- 头衔与亮点各 1 行；不写生平段落
