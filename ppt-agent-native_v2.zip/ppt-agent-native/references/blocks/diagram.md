# diagram -- 流程/关系图

> 原 HTML 自由绘图的原生降级：编号卡片链 + 细线连接。只表达线性流程与简单分组，复杂拓扑改叙事。

## 配方：水平流程链（3–4 步）

- 步骤卡：card（badge 1..n，filled），w 2.8 h 1.6，x 步进 3.2，y 3.0
- 连接线：相邻卡之间 line shape（w 0.4，y 3.8，color accent_1，width 1.5）
- 终点步骤若是结论可用 accent 卡

## 配方：分组关系（2–3 组）

tint 卡作分组底（大 frame），组内叠放 2–3 个小 filled 卡（间距 0.2），组标题用组底卡 title。

## 规则

- 超过 5 节点 / 有分支回环的图：不要硬画——改 waterfall 布局分步叙述，或拆成两页
- 箭头方向靠排列顺序表达（左→右、上→下）；不提供斜线箭头
- 连接线计 shape 预算；planning 给 diagram 页的 decoration_budget ≥ 连接线数 + 1
