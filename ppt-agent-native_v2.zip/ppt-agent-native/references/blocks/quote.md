# quote -- 金句/引用

> 一句话独占舞台。不包卡片——文字直接悬浮在留白中（原 transparent 语义）。

## 配方

```json
{ "type": "text", "frame": {"x":2.0,"y":2.7,"w":9.33,"h":1.8}, "size": 30, "align": "center",
  "runs": [ {"text":"“把复杂留给系统，"}, {"text":"把简单留给客户。","bold":true,"color":"accent_1"} ] }
{ "type": "text", "role": "caption", "frame": {"x":2.0,"y":4.7,"w":9.33,"h":0.4},
  "text": "—— 客户成功年度调研，2026", "size": 11, "color": "text_secondary", "align": "center" }
```
装饰：左上放大号引号 text（size 90，color grid）或 W1 短横条居中（x 6.12）。

## 规则

- 金句 ≤2 行（30pt 下每行 ≤18 个汉字）；关键短语用 runs 加粗/accent 上色
- 出处必须 caption 化；单焦点布局，页面其余保持留白
