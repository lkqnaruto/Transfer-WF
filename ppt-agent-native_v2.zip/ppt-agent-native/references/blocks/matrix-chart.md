# matrix-chart -- 矩阵/象限

> 2×2 象限的原生解法：田字格 tint 卡 + 轴标签。定位图/优先级矩阵用。

## 配方（2×2）

- 四象限 tint 卡：w 5.9 h 2.3，x = 0.67 / 6.77，y = 1.8 / 4.3（间距 0.2）
- 轴线：横 line（x 0.67 y 4.2 w 11.99）+ 竖 line（x 6.67 y 1.8 h 4.8），color grid
- 轴标签：4 个 caption text 放轴端（如 高↑/低↓、成本→）
- 每象限：title（象限名，bold）+ body 1–2 行举例；重点象限换 accent 卡（全页唯一）

## 规则

- 象限内条目 ≤2 行；矩阵页不再放其他 chart（一页一个矩阵就是满的）
- >2×2 的矩阵改用 table 配方（comparison.md 配方 B）
