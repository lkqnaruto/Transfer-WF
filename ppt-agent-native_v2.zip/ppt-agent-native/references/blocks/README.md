# 组件系统（native spec 配方版）

> planning 的 `card_type` 路由到本目录；每个文件给出该组件在 spec 中的元素组合配方。
> 所有配方只使用 8 种 spec 元素（text/bullets/card/kpi/chart/table/shape/image）。
