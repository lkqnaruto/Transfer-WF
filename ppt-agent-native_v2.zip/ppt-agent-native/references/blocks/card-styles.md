# 卡片视觉变体（card_style）-- native 决策表

> card_style 决策表：5 种视觉存在感 -- filled(实体基底) / outline(虚境描边) / tint(轻背景) / accent(灼焰核心) / elevated(悬浮岩)。
> 规则：每页 ≥2 种混用打破单调，accent 和 elevated 各最多 1 个/页。
> card_type 与 card_style 共鸣：data_highlight 用 kpi 元素或 accent 卡、quote 用无卡 text、timeline/diagram 用 shape 骨架、comparison 用 outline、data/text/list 用 filled/outline。

## 5 种变体（视觉配方在 style.json.card_recipes，spec 只写名字）

| card_style | 存在感 | 何时用 |
|---|---|---|
| filled | 扎实基底层 | 常规内容卡的默认；一页最多 2/3 卡用它 |
| outline | 若有若无的边界 | 次要信息、风险注记、旁白 |
| tint | 比 outline 更轻的底色区 | 分组背景、glass 的原生降级 |
| accent | 页面唯一燃点 | 最想被记住的一张卡（推荐/结论）；**≤1/页** |
| elevated | 物理浮起（带阴影） | 空间上"更近"的核心卡；**≤1/页** |

## 反面清单

- 全页 filled = 没有主角；全页同 style = 无层次
- accent + elevated 同时给两张卡 = 两个聚光灯等于没有
- 原 HTML 的 transparent/glass：transparent → 直接用 text/kpi 裸元素（不包卡）；glass → tint
