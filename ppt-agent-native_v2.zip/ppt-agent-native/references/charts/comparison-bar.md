# comparison-bar -- 对比条形图

> 类目间量级对比。横向 `bar`（类目名长）或纵向 `column`（类目名短/时间序）。

## 配方

```json
{ "type": "chart", "chart_type": "bar", "frame": {"x":0.5,"y":1.7,"w":7.4,"h":4.4},
  "categories": ["方案A","方案B","方案C"], "series": [{"name":"年成本","values":[420,260,180]}],
  "show_values": true }
```

- 单系列：show_legend 自动关；把系列含义写进页副标题
- 双系列（如 2025 vs 2026）：≤5 类目，show_legend 自动开
- 排序：按数值降序排类目（除非类目有天然顺序）
