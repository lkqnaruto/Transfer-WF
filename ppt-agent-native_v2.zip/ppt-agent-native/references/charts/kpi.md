# kpi -- 大数字锚点

> 单个核心指标的最强表达。直接用 spec 的 kpi 元素，不是 chart。

## 配方

```json
{ "type": "kpi", "frame": {"x":7.5,"y":1.7,"w":2.6,"h":1.5},
  "value": "34%", "label": "3 年复合增长率", "color": "accent_1", "value_size": 54 }
```

- value 带单位符号（% / 亿 / ×），≤6 字符最有力；label 一行说清指标口径
- 全页最重要的一个数字给 accent_1 + 最大 value_size（60–72）；次要 kpi 用 text_primary 色 + 44
- 趋势方向可在 value 前缀 ↑↓（"↑ 34%"）
