# timeline（chart 语境）-- 趋势时间线

> 数据随时间的趋势用原生 line/area；里程碑叙事时间线走 blocks/timeline.md 的 shape 骨架。

## 配方

```json
{ "type": "chart", "chart_type": "line", "frame": {"x":0.5,"y":1.7,"w":7.4,"h":4.4},
  "categories": ["2022","2023","2024","2025","2026E"],
  "series": [{"name":"营收","values":[1.8,3.1,5.8,9.6,15.2]}], "show_values": true }
```

- 强调"累积量/面积感"用 `area`；两条线对比时 show_legend 自动开
- 预测段（E 后缀类目）在副标题注明口径；拐点数值配 kpi 或 W7 强调点点破
