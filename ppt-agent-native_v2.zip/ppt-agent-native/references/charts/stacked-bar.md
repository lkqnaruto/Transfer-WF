# stacked-bar -- 堆叠条/柱

> 总量 + 构成的双重信息。`column_stacked`（时间演化）或 `bar_stacked`（类目构成）。

## 配方

```json
{ "type": "chart", "chart_type": "column_stacked", "frame": {"x":0.5,"y":1.7,"w":6.6,"h":4.4},
  "categories": ["2023","2024","2025","2026E"],
  "series": [ {"name":"企业级","values":[3.1,5.8,9.6,15.2]}, {"name":"消费级","values":[6.9,8.2,9.4,11.0]} ],
  "show_values": true }
```

- 堆叠段 ≤3 个（多了每段太薄读不出）；数据标签自动居中（builder 防呆，勿试 outEnd）
- 讲"占比变化"时旁边配 kpi 点出首尾占比（如 31% → 58%），不要指望读者自己算
