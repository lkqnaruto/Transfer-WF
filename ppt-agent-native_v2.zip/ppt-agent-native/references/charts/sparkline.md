# sparkline -- 迷你趋势线

> 卡片内微型趋势的原生降级：小尺寸 line chart 或"kpi + 趋势符号"。

## 配方 A：小型 line chart（有 4+ 数据点时）

```json
{ "type": "chart", "chart_type": "line", "frame": {"x":8.3,"y":4.4,"w":4.4,"h":1.8},
  "categories": ["Q1","Q2","Q3","Q4"], "series": [{"name":"trend","values":[52,61,58,74]}] }
```
最小可读尺寸 4.0×1.6in；再小轴字会挤压——不要塞进卡片内部。

## 配方 B：kpi + 趋势前缀（卡片内/空间不足时）

kpi 元素，value 写 "↑ 74"，label 写 "Q4 · 环比 +27%"。零图表成本，卡内友好。

## 规则

- HTML 时代的"每卡一条 sparkline"在原生版不可行；一页 ≤1 个迷你 chart，其余用配方 B
