# treemap -- 矩形树图（强制降级）

> PowerPoint 2016+ 有原生 treemap 但 pptxgenjs 无法生成。两种降级，不得画图片。

## 降级 A：占比 bar + 构成表（推荐）

`chart_type: "bar"` 按占比降序（≤6 项，尾部并"其他"）+ 右侧 caption 注总盘子。

## 降级 B：比例色块拼图（仅低密度展示页）

2–4 个 tint/filled 卡按占比分配面积拼成一个大矩形区（总 frame 如 x 0.5 y 1.7 w 7.4 h 4.4），
最大块用 accent 卡，每块 title = "名称 NN%"。块数 >4 立即退回降级 A。

## 规则

- treemap 的语义是"构成 + 层级"；只有一层构成时 bar/doughnut 本来就更诚实
- 降级 B 的面积只需近似比例（视觉传达），精确数字必须写在块 title 里
