# 图表系统（native 版）

> planning 的 `chart.chart_type` 路由到本目录。三类实现：
> **原生 chart 元素**（bar/column/line/area/pie/doughnut/radar 及 stacked 变体）、
> **shape 组合**（kpi/metric-row/progress-bar/rating）、
> **强制降级**（treemap/funnel/waffle/sparkline -- 无原生形式，按对应文件的降级方案）。
> 全局规则见 `runtime-chart-rules.md`（每个 chart 页必读）。
