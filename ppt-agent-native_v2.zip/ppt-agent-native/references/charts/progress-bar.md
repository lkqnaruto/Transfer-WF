# progress-bar -- 进度条

> 单一完成度/达成率。双 rect shape 组合，不是 chart。

## 配方（72% 示例，轨道宽 5.0in）

```json
{ "type": "shape", "shape": "roundRect", "frame": {"x":0.5,"y":3.0,"w":5.0,"h":0.28}, "fill": "grid", "radius": 0.14 }
{ "type": "shape", "shape": "roundRect", "frame": {"x":0.5,"y":3.0,"w":3.6,"h":0.28}, "fill": "accent_1", "radius": 0.14 }
{ "type": "text", "frame": {"x":5.65,"y":2.92,"w":1.2,"h":0.4}, "text": "72%", "size": 16, "bold": true, "color": "accent_1" }
```
填充宽 = 轨道宽 × 比例（5.0 × 0.72 = 3.6），两 rect 同 x 同 y 同 h。

## 规则

- 多条进度并列时轨道等宽对齐，标签列右对齐；≥4 条改用 bar 图
- 每条 2 shape，先数 decoration_budget（进度条属信息图形，planning 需给足预算）
