# ring -- 环形占比

> 单一占比/构成。原生 `doughnut`；单一比例更推荐 kpi + progress-bar。

## 配方

```json
{ "type": "chart", "chart_type": "doughnut", "frame": {"x":8.3,"y":1.7,"w":4.4,"h":3.6},
  "categories": ["已迁移","未迁移"], "series": [{"name":"进度","values":[72,28]}],
  "hole_size": 60 }
```

- 扇区 ≤4 个（多了改 bar）；中心留洞处不可叠字（原生图表不支持中心文字），
  核心数字用旁置 kpi 元素给出
- "单个百分比"场景优先 kpi（大数字本身就是最强表达），环图仅当构成 ≥2 段有意义时用
