# Runtime Chart Rules（全局图表规则，chart 页必读）

> spec 的 chart 元素如何取值；安静框架默认值由 `slide_builder.js` 统一注入，spec 不可也不必调轴样式。

## 硬规则

1. `chart_type` 只有 9 个合法值：`bar | column | bar_stacked | column_stacked | line | area | pie | doughnut | radar`
2. 每条 `series.values` 长度必须等于 `categories` 长度（Gate 拦截）
3. 配色自动取 style.json 的 `chart_palette`，spec 不写颜色
4. builder 自动：无图表标题（页标题已承担）、轴字 10pt text_secondary、横向网格线 grid 色 0.5pt、类目网格线关闭
5. `show_values: true` 时数据标签 9pt；**stacked 类强制居中标签**（outEnd 会损坏文件，builder 已防呆）
6. 图例：饼/环与多系列默认开，单系列默认关；可用 `show_legend` 覆盖
7. 数值轴范围：默认自动；对比页可用 `val_max` 拉平两图坐标
8. 一页 ≤ `max_charts`（通常 1）；图表 frame 高 ≥2.5in，宽 ≥4in，否则轴字挤压

## 数据准备

- 类目 ≤6 个（多了轴字重叠：合并尾部为"其他"）
- 系列 ≤3 条；数字保留 1 位小数以内；单位写进页副标题或 caption，不写进类目名
