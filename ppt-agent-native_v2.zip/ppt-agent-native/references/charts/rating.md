# rating -- 评分点

> 1–5 档评分的圆点表达。oval shape 组合。

## 配方（4/5 分示例）

oval ×5：w 0.18 h 0.18，x 步进 0.28，y 同行；前 4 个 fill accent_1，第 5 个 fill grid。

```json
{ "type": "shape", "shape": "oval", "frame": {"x":8.3,"y":2.1,"w":0.18,"h":0.18}, "fill": "accent_1" }
```

## 规则

- 评分行配右侧 caption 注分值（"4/5"）；多行评分对象名列左对齐
- 每行 5 shape ——预算大户：≥4 行评分改用 table（星号字符 ★★★★☆ 进单元格，零 shape 成本）
