# metric-row -- 指标行

> 3–4 个 KPI 并排组成仪表带。hero-top 布局的顶带标准内容。

## 配方（4 指标版）

kpi 元素 ×4：w 2.9 h 1.6，x = 0.5 / 3.65 / 6.8 / 9.95，y 1.7。
分隔：相邻 kpi 之间可放竖 line shape（h 1.2，color grid，width 0.5，计装饰预算）。

```json
{ "type": "kpi", "frame": {"x":0.5,"y":1.7,"w":2.9,"h":1.6}, "value": "¥262亿", "label": "市场规模 2026E" }
```

## 规则

- 同行 kpi 的 value_size 一致（默认 44）；只有一个允许 accent_1 色（视觉入口）
- 指标口径同源同期；3 个比 4 个几乎总是更好
