# 风格系统（原生 Token 版）

> 非默认资料。human-only creative workbook。运行时真源是 `runtime-style-rules.md` 与各 `*.json` 预置。

## 与 HTML 版的根本差异

风格不再是 CSS 变量，而是 **pptx 设计 Token**：`slide_builder.js` 直接消费 `style.json` 的
`fonts / colors / card_recipes / chart_palette`。spec 里只写 token 名，换肤只改 style.json。

## style.json 数据模型（native）

```json
{
  "style_id": "blue_white_native",
  "style_name": "...",
  "mood_keywords": ["..."],
  "design_soul": "一句话灵魂宣言（页面情绪锚点，不进入版面文案）",
  "variation_strategy": "跨页变奏策略",
  "decoration_dna": {
    "signature_move": "唯一标志性装饰（用 shape 元素实现，每 3-4 页至少出现一次）",
    "forbidden": ["硬边界装饰清单"],
    "recommended_combos": ["推荐组合 A", "推荐组合 B"]
  },
  "fonts": { "heading": "Microsoft YaHei", "body": "Microsoft YaHei" },
  "colors": {
    "bg_primary": "FFFFFF", "bg_secondary": "F8FAFC",
    "card_bg": "F1F5F9", "card_border": "DBEAFE",
    "text_primary": "1E293B", "text_secondary": "64748B",
    "accent_1": "2563EB", "accent_2": "1D4ED8", "accent_3": "059669", "accent_4": "B45309",
    "on_accent": "FFFFFF", "grid": "E2E8F0"
  },
  "chart_palette": ["accent_1", "accent_3", "accent_2", "accent_4"],
  "card_recipes": {
    "filled":   { "fill": "card_bg", "line": {"color":"card_border","width":0.75}, "shadow": false, "title_color": "text_primary", "text_color": "text_secondary" },
    "outline":  { "fill": null, "line": {"color":"accent_1","width":0.5}, "shadow": false, "title_color": "text_primary", "text_color": "text_secondary" },
    "accent":   { "fill": "accent_1", "line": null, "shadow": false, "title_color": "on_accent", "text_color": "on_accent" },
    "elevated": { "fill": "bg_primary", "line": {"color":"grid","width":0.5}, "shadow": true, "title_color": "text_primary", "text_color": "text_secondary" },
    "tint":     { "fill": "bg_secondary", "line": null, "shadow": false, "title_color": "text_primary", "text_color": "text_secondary" }
  }
}
```

规则：颜色一律 6 位 hex **无 #**（8 位或带 # 会损坏 pptx）；11 个 colors 键全部必填；
5 个 card_recipes 全部必填；字体必须是 Windows 原生（Microsoft YaHei / SimHei / DengXian /
Segoe UI / Calibri / Cambria / Arial 等）。Gate：`spec_validator.py style <style.json>`。

## CSS 效果 → 原生降级对照表（强制遵守）

| HTML/CSS 效果 | 原生等价 | 说明 |
|---|---|---|
| 渐变背景 / 渐变卡片 | 双色分层：bg_primary + bg_secondary 大色块 | pptxgenjs 不支持渐变填充 |
| 毛玻璃 (backdrop-blur) | `tint` 卡片 或 fill_transparency + shadow | 玻璃感不可原生复刻 |
| 光晕 / glow | elevated 卡片（阴影）+ accent 描边 | 阴影 offset 必须 ≥0 |
| 网格点阵底纹 | L 形角标线（2 条 line shape） | 100+ 点阵 shape 会爆炸文件 |
| 大号半透明水印字 | text 元素 + 浅 token 色（如 grid） | 无透明文字，用浅色替代 |
| clip-path 斜切 | 放弃，用色块矩形 | 无原生等价 |
| CSS 动画 | 放弃 | 静态介质 |
| 半透明色叠层 (rgba) | fill_transparency: 0-100 | 绝不用 8 位 hex |
