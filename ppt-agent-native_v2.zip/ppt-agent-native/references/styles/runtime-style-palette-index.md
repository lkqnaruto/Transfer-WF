# Runtime Style Palette Index（native 版）

> 一句话定位（引用层）：预置风格菜单；Style subagent 选型或自创的调色起点。

| style_id | 文件 | 底色 | 一句话气质 | 适用 |
|---|---|---|---|---|
| blue_white_native | blue-white.json | 浅 | 顶级咨询报告的克制蓝 | 企业介绍、汇报、培训、金融/医疗、默认 |
| dark_tech_native | dark-tech.json | 深 | 深空控制台的冷青微光 | 技术发布、开发者工具、AI/ML 展示 |

自创风格：复制最接近的预置，改 `colors` 与 `decoration_dna`，保持 11 色键 + 5 卡片配方完整，
过 `spec_validator.py style` Gate 即可投产。命名 `OUTPUT_DIR/style.json`（运行时唯一真源）。
