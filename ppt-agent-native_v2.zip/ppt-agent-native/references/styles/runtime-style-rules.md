# Runtime Style Rules（Step 3.5 注入 -- native 版）

> 一句话定位（引用层）：Style subagent 产出 style.json 的执行规则；输出的是 pptx 设计 Token，不是 CSS 变量。

## 输出合同

产出一份符合 `styles/README.md` 数据模型的 `style.json`，必须包含：
`style_id` `style_name` `mood_keywords` `design_soul` `variation_strategy` `decoration_dna`
`fonts` `colors`（11 键全）`chart_palette` `card_recipes`（5 键全）。

Gate：`python spec_validator.py style OUTPUT_DIR/style.json` 必须退出 0。

## 硬规则

1. **颜色**：6 位 hex、无 #。深浅底二选一后全套自洽：浅底 text_primary 用深灰蓝系，深底用浅灰系；`on_accent` 必须与 `accent_1` 形成 ≥4.5:1 对比。
2. **字体**：只用 Windows 原生字体。中文内容默认 `Microsoft YaHei`（heading/body 可同名）；纯英文可用 Segoe UI + Calibri 组合。禁止 Google Fonts、禁止 Aptos。
3. **色彩主从**：accent_1 是唯一主强调（60-70% 强调场景），accent_2 为其深/浅变体，accent_3/4 是数据对比色。禁止四色平权。
4. **decoration_dna.signature_move 必须可用 shape 元素实现**（rect/roundRect/oval/line 的组合），并注明尺寸。凡是降级对照表标"放弃"的效果不得写入。
5. **card_recipes 层次感**：五种配方必须拉开存在感差距（filled=基底 / outline=轻 / tint=更轻 / accent=唯一燃点 / elevated=唯一浮起），不得五种同质。
6. **chart_palette** 引用 colors token 名（3-4 项），首位必须是 accent_1。
7. 参考预置：`blue-white.json`（通用商务默认）、`dark-tech.json`（技术发布会）。可基于预置微调色值或自创，但结构与 Gate 不变。

## 选型指引

| 场景 | 起点 |
|---|---|
| 企业汇报 / 培训 / 未指定 | blue-white.json |
| 技术产品 / 开发者 / AI 展示 | dark-tech.json |
| 用户有品牌色 | 以品牌色为 accent_1 自创，中性色从预置借 |
