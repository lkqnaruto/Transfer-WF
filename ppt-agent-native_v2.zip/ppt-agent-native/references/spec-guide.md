# Slide Spec Guide -- slide-N.spec.json 权威参考

> 一句话定位（引用层）：声明式单页描述，`slide_builder.js` 的唯一输入、QA 的唯一修改面；本文件是 PageAgent 写 spec 的完整语法参考。

执行真源：`scripts/spec_validator.py`（Gate）与 `lib/render_core.js`（渲染语义）。本文与真源冲突时以真源为准。

## 顶层结构

```json
{
  "spec_version": "1.0",
  "page": 3,
  "page_type": "content",
  "title": "页面标题（builder 自动排版；null = 本页自排标题）",
  "subtitle": "可选副标题",
  "layout_id": "primary-secondary",
  "background": "bg_primary",
  "density_contract": { "...从 planningN.json 逐字段复制..." },
  "notes": "演讲者备注（纯文本，进入 PowerPoint 备注页）",
  "elements": [ ... ]
}
```

- `page_type`: `cover | toc | section | content | end`
- `background` 与一切颜色字段：**只写 style.json 的 token 名**（`bg_primary` `bg_secondary` `card_bg` `card_border` `text_primary` `text_secondary` `accent_1..4` `on_accent` `grid`）；裸 hex 仅限一次性特殊色（6 位、无 #）
- `density_contract` 必须完整携带 11 个键：`deck_bias` `density_label` `page_lower_bound` `page_upper_bound` `max_cards` `max_charts` `min_body_font_pt` `max_lines_per_card` `image_policy` `decoration_budget` `overflow_strategy`

## 画布与标题区

- 画布 13.333 × 7.5 英寸；`frame` = `{"x","y","w","h"}` 英寸，2 位小数
- builder 按 `page_type` 自动渲染 title/subtitle：content/toc 标题占 y=0.35–1.5（内容从 **y≥1.6** 开始）；cover/end 居中大标题；section 左侧大标题
- 内容元素距画布边缘 ≥0.4in；shape/image 允许贴边出血
- 字号单位 pt；正文 ≥ `min_body_font_pt`；来源/日期等辅助行加 `"role": "caption"`（下限 8pt）

## 元素类型（8 种）

每个元素必有 `id`（对应 planning 的 card_id）、`type`、`frame`。

### text — 单段文字
```json
{ "id": "t1", "type": "text", "frame": {...}, "text": "...", "size": 14,
  "color": "text_primary", "bold": false, "align": "left", "valign": "top" }
```
富文本用 `runs`: `[{"text":"关键词","bold":true,"color":"accent_1"},{"text":"其余"}]`。

### bullets — 列表（禁止在文案里手写 • 符号）
```json
{ "id": "b1", "type": "bullets", "frame": {...}, "size": 13, "numbered": false,
  "items": [ {"text":"重点项","bold":true}, "普通项", "普通项" ] }
```

### card — 卡片（背景 + 可选编号徽章 + 标题 + 正文）
```json
{ "id": "c1", "type": "card", "card_style": "filled", "frame": {...},
  "badge": "1", "title": "卡片标题", "title_size": 15,
  "body": ["第一行", "第二行"], "body_size": 12, "bulleted": false }
```
`card_style`: `filled | outline | accent | elevated | tint`（视觉配方在 style.json.card_recipes）。
**每页 accent ≤1、elevated ≤1；每页至少混用 2 种 card_style；body 行数 ≤ max_lines_per_card。**

### kpi — 大数字锚点（值 + 小标签，自带排版）
```json
{ "id": "k1", "type": "kpi", "frame": {...}, "value": "87%",
  "label": "客户留存率", "color": "accent_1", "value_size": 54 }
```

### chart — 原生 PowerPoint 图表
```json
{ "id": "ch1", "type": "chart", "chart_type": "column", "frame": {...},
  "categories": ["2023","2024"], "series": [{"name":"营收","values":[3.1,5.8]}],
  "show_values": true, "show_legend": true }
```
`chart_type`: `bar | column | bar_stacked | column_stacked | line | area | pie | doughnut | radar`。
每条 series 的 values 长度必须等于 categories 长度。treemap/funnel/sankey 无原生形式——按 charts/ 参考文件降级（条形图或表格），不得画图片。

### table — 原生表格（首行默认表头，accent 底 + on_accent 字）
```json
{ "id": "tb1", "type": "table", "frame": {...}, "font_size": 12,
  "rows": [["维度","方案A","方案B"],["成本","高","低"]], "col_widths": [1.7,1.9,1.9] }
```
所有行列数必须一致。

### shape — 装饰图形（计入 decoration_budget）
```json
{ "id": "s1", "type": "shape", "shape": "rect", "frame": {...}, "fill": "accent_1" }
```
`shape`: `rect | roundRect | oval | line`；line 只用 `line: {"color":"accent_1","width":1}`。
典型用法：标题下短横条（0.06in 高）、L 形角标（两条 line）、分隔细线。

### image — 外部图片（受 image_policy 管制）
```json
{ "id": "im1", "type": "image", "frame": {...}, "path": "images/foo.png", "sizing": "cover" }
```
`image_policy: "none"` 时禁止出现。

## 布局速算

- 同排 n 张卡：`n×w + (n-1)×gap ≤ 12.53`（gap 取 0.25–0.4）
- 三分栏：w=4.0，x = 0.5 / 4.67 / 8.83
- 主次栏（primary-secondary）：主区 x=0.5 w=7.4，次区 x=8.3 w=4.53
- 内容区可用高度：y 1.6 → 7.1（底部留 0.4）；有 caption 行时内容到 6.8

## 违例即 Gate 拦截（spec_validator）

出画布 frame、未解析 token、chart 数据长度不齐、body 超行、card/chart/decoration 超预算、正文小于 min_body_font_pt、image_policy 违例、accent/elevated 超 1、表格行列不齐、page_type/chart_type/card_style 枚举外取值。
