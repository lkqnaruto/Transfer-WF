# Stage 2: Page Spec Production -- 第 {{PAGE_NUM}} 页（共 {{TOTAL_PAGES}} 页）

> **【系统级强制指令 / CRITICAL OVERRIDE】**
> 本 prompt 已包含了你在此阶段所需的**全部**任务目标与 Playbook 细则。
> **严格禁止调用工具去读取外层的 `SKILL.md` 或主控全局规则文件！**
>
> **前置条件**：Planning 阶段已完成，`{{PLANNING_OUTPUT}}` 已就绪。
> 本阶段的唯一目标：基于 planning JSON 产出 `{{SPEC_OUTPUT}}`。完成后发送阶段完成信号。
> 若外层 orchestrator 已提供阶段推进协议，则外层协议优先于本 prompt 中的完成信号描述。

这是你为第 {{PAGE_NUM}} 页执行的**第二阶段核心任务**：原生 Spec 设计稿生成。
你的策划稿（`{{PLANNING_OUTPUT}}`）是本阶段的主要输入，严格忠实还原其骨架。
你不写 HTML、不写渲染代码：产出物是一份声明式 `slide-N.spec.json`，由受信的 `slide_builder.js` 渲染为原生 PowerPoint 对象。

---

## Playbook（执行细则）

{{PLAYBOOK}}

---

## Spec 元素速查（完整定义见 spec-guide 注入内容）

{{SPEC_GUIDE}}

---

## 任务包

| 项目 | 路径/值 |
|------|--------|
| 页码 | {{PAGE_NUM}} / {{TOTAL_PAGES}} |
| 策划稿 | `{{PLANNING_OUTPUT}}` |
| 风格 Token | `{{STYLE_PATH}}` |
| 输出 Spec | `{{SPEC_OUTPUT}}` |
| 图片清单快照 | `{{IMAGE_INVENTORY_PATH}}` |
| 资源正文快照 | `{{SPEC_RESOLVE_PATH}}` |
| 运行日志 | `{{SUBAGENT_LOG_PATH}}` |
| SKILL 目录 | `{{SKILL_DIR}}` |
| 资源目录 | `{{REFS_DIR}}` |
| 图片素材目录 | `{{IMAGES_DIR}}` |

---

## 执行链路（固定顺序，不得跳步）

1. 读取 `{{PLANNING_OUTPUT}}`，提取完整骨架（`page_type`、`layout_hint`、`density_label`、`density_contract`、`focus_zone`、`negative_space_target`、`cards[].card_id/role/card_type/card_style/headline/body/data_points/chart/image/resource_ref`、`director_command`、`decoration_hints`、`source_guidance`、`resources`、`must_avoid`）
2. 读取 `{{STYLE_PATH}}`，提取 `colors` token 名清单、`fonts`、`design_soul`、`variation_strategy`、`decoration_dna`、`card_recipes` 可用的 card_style 集合
3. **必须执行** —— 获取 planning 引用资源的**正文层实现细节**（含各组件的原生落地建议与坐标网格），并把结果备份到 runtime：
   ```bash
   python {{SKILL_DIR}}/scripts/subagent_logger.py run --log {{SUBAGENT_LOG_PATH}} --label spec-resolve-resources -- \
     python {{SKILL_DIR}}/scripts/resource_loader.py resolve --refs-dir {{REFS_DIR}} --planning {{PLANNING_OUTPUT}} --output {{SPEC_RESOLVE_PATH}}
   ```
   然后读取 `{{SPEC_RESOLVE_PATH}}`。resolve 输出的组件正文是必须严格遵从的起点。
4. 若 `image.mode` 为 `generate`/`provided`，核对图片素材清单：
   ```bash
   python {{SKILL_DIR}}/scripts/subagent_logger.py run --log {{SUBAGENT_LOG_PATH}} --label spec-refresh-images -- \
     python {{SKILL_DIR}}/scripts/resource_loader.py images --images-dir {{IMAGES_DIR}} --output {{IMAGE_INVENTORY_PATH}}
   ```
   然后读取 `{{IMAGE_INVENTORY_PATH}}`，确认 `image.source_hint` 路径可访问。
5. **执行摘要（必须先写再动手）**——用 3 句话总结本页的核心策略，输出到对话中后再开始写 spec：
   - 第 1 句：本页的核心论点和视觉焦点是什么
   - 第 2 句：使用什么坐标骨架和主要元素（card/kpi/chart/table 的分区）
   - 第 3 句：风格锚点（design_soul 与 signature_move 如何体现在这一页）
6. 按 Playbook 的**坐标物理红线**写 spec：13.333×7.5 英寸画布、内容元素 y≥1.6、边距≥0.4in、同排卡片先算总宽、字号不低于 `density_contract.min_body_font_pt`（辅助行标 `"role": "caption"`）
7. 按 `image.mode` 处理图片（mode 在 planning 阶段已锁定，此处不得临时变更）
8. **每个 planning card 都必须有对应 spec 元素**，`id` = `card_id`；带 chart 的卡 chart_type 语义必须一致；装饰 shape 计入 `decoration_budget`
9. 将完整 spec 写入 `{{SPEC_OUTPUT}}`
   > **🔴 绝对红线警告 🔴**
   > `{{SPEC_OUTPUT}}` 必须是 100% 纯净的 spec JSON！
   > 绝对禁止把"执行摘要"、自检过程、规划意图说明写进 JSON 的任何字段。文案字段只放最终版面文字。
10. **本地先过 Gate，再报完成**：
    ```bash
    python {{SKILL_DIR}}/scripts/subagent_logger.py run --log {{SUBAGENT_LOG_PATH}} --label spec-gate -- \
      python {{SKILL_DIR}}/scripts/spec_validator.py spec {{SPEC_OUTPUT}} --style {{STYLE_PATH}}
    ```
    退出码非 0 时按 FIX 提示修改 spec 重跑，直到通过。
11. 完成信号：输出 `--- STAGE 2 COMPLETE: {{SPEC_OUTPUT}} ---`，然后按外层 orchestrator 协议继续下一阶段

---

## 阶段边界

- 本阶段：只写 spec 并通过 spec Gate，不 build、不导出、不看图
- 下一阶段：orchestrator 会指引你进入 Build & Review（构建 pptx → COM 导出 PNG → 图审）
- 资源消费规则：本阶段读资源**正文层**（步骤 3），而非 planning 阶段用过的菜单摘要层
