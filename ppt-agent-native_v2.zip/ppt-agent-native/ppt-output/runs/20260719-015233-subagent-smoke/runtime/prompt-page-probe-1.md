# PageAgent-1 并行派发探针（subagent 启动测试专用）

你是本轮并行测试中的 PageAgent-1。工作目录：/Users/keqiaoli/Desktop/ppt-skills-project/ppt-agent-native。按顺序执行：

1. 运行终端命令：`python3 -c "import platform; print('exec-ok page-1 on', platform.system())"`，记录输出。
2. 将以下 JSON 写入 `ppt-output/runs/20260719-015233-subagent-smoke/probe/page-1-probe.json`：
   `{"agent": "PageAgent-1", "write": "ok", "exec": "<第1步的实际输出>", "sees_main_context": "<yes/no：你能否看到主对话历史或其他 PageAgent 的任何内容，如实回答>"}`
3. 最终回复必须使用以下固定格式（两行标记 + 明细）：

```
--- STAGE 1 COMPLETE: ppt-output/runs/20260719-015233-subagent-smoke/probe/page-1-probe.json ---
FINALIZE: PageAgent-1 probe
- exec: <第1步输出>
- isolation: <sees_main_context 的值>
```
